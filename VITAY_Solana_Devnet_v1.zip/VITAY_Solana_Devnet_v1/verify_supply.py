import json
from decimal import Decimal

with open("distribution.json", encoding="utf-8") as f:
    data = json.load(f)

target = Decimal(str(data["total_supply"]))
allocations = {k: Decimal(str(v)) for k, v in data["allocations"].items()}
total = sum(allocations.values())
assert total == target, f"Allocation total {total} != target {target}"
assert all(v >= 0 for v in allocations.values()), "Negative allocation detected"
print(f"PASS: allocation total = {total} VITAY")
print("PASS: no negative allocations")
print("On-chain mint/supply must still be verified separately.")

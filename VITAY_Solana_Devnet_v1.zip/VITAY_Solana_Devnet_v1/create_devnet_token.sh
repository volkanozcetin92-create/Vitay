#!/usr/bin/env bash
set -euo pipefail
solana config set --url devnet
solana address
solana balance
printf '\nCreating a VITAY Devnet mint (9 decimals)...\n'
spl-token --url devnet create-token --decimals 9
printf '\nRecord the public Mint Address. Never share a seed phrase/private key.\n'

# VITAY — Solana Devnet v1

Educational/testnet project. **DEVNET ONLY.**

- Network: Solana Devnet
- Token program: Original SPL Token Program
- Name/Symbol: VITAY
- Decimals: 9
- Target maximum supply: 10,550,000 VITAY
- Base units at 9 decimals: 10,550,000,000,000,000

This package contains no private key or seed phrase. Never put wallet secrets into it.

## Workflow
1. Use a dedicated Devnet wallet.
2. Select Devnet.
3. Create the mint with 9 decimals.
4. Record the public mint address in `devnet.env`.
5. Create the associated token account.
6. Mint only the amount you have deliberately verified.
7. Run `verify_supply.py` to verify the local allocation plan.
8. Verify the on-chain supply and mint authority before proceeding.

Devnet is for development/testing and can be reset. Do not treat Devnet tokens as having real financial value.

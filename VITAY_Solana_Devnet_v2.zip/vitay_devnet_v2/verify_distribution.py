import json
from decimal import Decimal
from pathlib import Path

data=json.loads(Path('distribution.json').read_text(encoding='utf-8'))
target=Decimal(str(data['total_supply']))
alloc={k:Decimal(str(v)) for k,v in data['allocations'].items()}
total=sum(alloc.values())
assert total == target, (total, target)
assert all(v >= 0 for v in alloc.values())
assert set(alloc) == {'FOUNDER','COMMUNITY','DEVELOPMENT','LIQUIDITY','RESERVE','PROMOTION','MINING','REWARD'}
print(f'PASS: planned allocation = {total} VITAY')
print(f'Base units at {data["decimals"]} decimals = {int(target * (Decimal(10) ** data["decimals"]))}')

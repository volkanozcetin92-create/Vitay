# VITAY Solana Devnet v2

Educational/testnet package. DEVNET ONLY.

- Network: Solana Devnet
- Token: VITAY
- Decimals: 9
- Planned maximum supply: 10,550,000 VITAY
- Token program: original SPL Token Program

Security rules:
- Never put a seed phrase or private key in this package.
- Use a dedicated Devnet wallet.
- Verify the mint address before minting.
- Keep mint authority controlled until supply verification is complete.
- Do not use these scripts against Mainnet.

This package prepares and verifies the workflow; it does not create a real-money asset or guarantee production security.

# VITAY v2.1 Secure Testnet

VITAY, eğitim ve test amacıyla geliştirilen bağımsız blockchain prototipidir.

- Maksimum arz: 10,550,000 VITAY
- Ed25519 imzalı işlemler
- Nonce/replay koruması
- Kontrollü PoW emisyonu
- SQLite kalıcılığı
- P2P node ve zincir senkronizasyonu
- PoW iş skoruna göre zincir seçimi
- Blok/işlem boyutu ve zaman kontrolleri

## Çalıştırma

```bash
pip install -r requirements.txt
python -m VITAY_v1.test_vitay
```

> Bu proje bağımsız güvenlik denetiminden geçmemiştir. Gerçek para veya üretim ağı olarak kullanılmadan önce kapsamlı audit, fuzzing ve dağıtık ağ testleri gerekir.

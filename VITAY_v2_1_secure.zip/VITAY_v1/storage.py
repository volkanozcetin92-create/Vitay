import json, sqlite3
from pathlib import Path

class ChainStore:
    """SQLite persistence for the VITAY testnet node."""
    def __init__(self,path='vitay_node.sqlite3'):
        self.path=Path(path)
        self.db=sqlite3.connect(self.path,check_same_thread=False)
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('PRAGMA synchronous=FULL')
        self.db.execute('CREATE TABLE IF NOT EXISTS state (id INTEGER PRIMARY KEY CHECK(id=1), payload TEXT NOT NULL)')
        self.db.commit()
    def save(self,payload):
        raw=json.dumps(payload,ensure_ascii=False,separators=(',',':'))
        with self.db:
            self.db.execute('INSERT INTO state(id,payload) VALUES(1,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload',(raw,))
    def load(self):
        row=self.db.execute('SELECT payload FROM state WHERE id=1').fetchone()
        return json.loads(row[0]) if row else None
    def close(self): self.db.close()

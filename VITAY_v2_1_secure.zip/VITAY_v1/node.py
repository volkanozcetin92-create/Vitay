#!/usr/bin/env python3
"""VITAY v2 testnet P2P node. Production deployment requires TLS/firewall/auth hardening."""
import json, os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.request import Request, urlopen
from urllib.error import URLError
from threading import Lock
from .vitay import VITAYChain, PROTOCOL_VERSION
from .storage import ChainStore

MAX_BODY=2_000_000
MAX_PEERS=64
MAX_PEER_URL=256
PEER_TOKEN=os.environ.get('VITAY_PEER_TOKEN','')

class Node:
    def __init__(self, host='127.0.0.1', port=5000, data_file=None):
        self.host,self.port=host,port; self.peers=set(); self.chain=VITAYChain(); self.lock=Lock()
        self.store=ChainStore(data_file or f'vitay_node_{port}.sqlite3')
        saved=self.store.load()
        if saved: self.load_state(saved, persist=False, force=True)
    def url(self): return f'http://{self.host}:{self.port}'
    def add_peer(self,url):
        url=url.strip().rstrip('/')
        if not url.startswith(('http://','https://')): raise ValueError('Geçersiz peer URL')
        if len(url)>MAX_PEER_URL: raise ValueError('Peer URL çok uzun')
        if url!=self.url() and len(self.peers)<MAX_PEERS: self.peers.add(url)
    def state(self): return self.chain.export()
    def _auth_headers(self): return {'X-VITAY-Peer-Token':PEER_TOKEN} if PEER_TOKEN else {}
    def load_state(self,data,persist=True,force=False):
        candidate=VITAYChain(); candidate.import_chain(data)
        with self.lock:
            if force or candidate.work_score()>self.chain.work_score():
                self.chain=candidate
                if persist: self.store.save(self.state())
                return True
        return False
    def sync_peer(self,peer):
        try:
            req=Request(peer+'/state',headers=self._auth_headers())
            with urlopen(req,timeout=3) as r: data=json.loads(r.read().decode())
            return self.load_state(data)
        except Exception: return False
    def sync_all(self): return sum(1 for p in list(self.peers) if self.sync_peer(p))
    def broadcast_state(self):
        body=json.dumps(self.state(),separators=(',',':')).encode()
        for peer in list(self.peers):
            try:
                headers={'Content-Type':'application/json',**self._auth_headers()}
                req=Request(peer+'/state',data=body,headers=headers,method='POST')
                urlopen(req,timeout=3).read()
            except Exception: pass

class Handler(BaseHTTPRequestHandler):
    node=None
    def _authorized(self):
        if not PEER_TOKEN: return True
        return self.headers.get('X-VITAY-Peer-Token','')==PEER_TOKEN
    def _send(self,code,obj):
        data=json.dumps(obj,ensure_ascii=False,separators=(',',':')).encode(); self.send_response(code)
        self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
    def do_GET(self):
        if not self._authorized(): self._send(401,{'error':'unauthorized'}); return
        if self.path=='/state': self._send(200,self.node.state())
        elif self.path=='/peers': self._send(200,sorted(self.node.peers))
        elif self.path=='/status': self._send(200,{'node':self.node.url(),'height':len(self.node.chain.chain)-1,'work':self.node.chain.work_score(),'valid':self.node.chain.valid(),'peers':sorted(self.node.peers),'protocol_version':PROTOCOL_VERSION})
        else: self._send(404,{'error':'not found'})
    def do_POST(self):
        if not self._authorized(): self._send(401,{'error':'unauthorized'}); return
        if self.path not in ('/state','/peer'): self._send(404,{'error':'not found'}); return
        try:
            length=int(self.headers.get('Content-Length','0'))
            if length<0 or length>MAX_BODY: raise ValueError('İstek boyutu fazla')
            data=json.loads(self.rfile.read(length).decode())
            if self.path=='/peer': self.node.add_peer(data['url']); self._send(200,{'ok':True}); return
            changed=self.node.load_state(data); self._send(200,{'ok':True,'updated':changed})
        except Exception as e: self._send(400,{'ok':False,'error':str(e)})
    def log_message(self,*_): return

def serve(node):
    Handler.node=node; server=ThreadingHTTPServer((node.host,node.port),Handler)
    print(f'VITAY node çalışıyor: {node.url()}')
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser(description='VITAY eğitim/testnet P2P node')
    p.add_argument('--host',default='127.0.0.1'); p.add_argument('--port',type=int,default=5000); p.add_argument('--peer',action='append',default=[])
    args=p.parse_args(); n=Node(args.host,args.port)
    for peer in args.peer: n.add_peer(peer)
    n.sync_all(); serve(n)

"""Local VITAY wallet with password-encrypted Ed25519 private key."""
import base64, json, os
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from .crypto import generate_keypair

ITERATIONS=600_000

def _key(password,salt):
    return PBKDF2HMAC(algorithm=hashes.SHA256(),length=32,salt=salt,iterations=ITERATIONS).derive(password.encode())

def create_wallet(password):
    if len(password)<8: raise ValueError('Cüzdan parolası en az 8 karakter olmalı.')
    private_hex,public_hex=generate_keypair()
    return {'address':public_hex,'private_key':private_hex,'public_key':public_hex,'password':password}

def save_wallet(wallet,path):
    password=wallet.get('password')
    if not password: raise ValueError('Kaydetmek için parola gerekli.')
    salt,nonce=os.urandom(16),os.urandom(12)
    ct=AESGCM(_key(password,salt)).encrypt(nonce,bytes.fromhex(wallet['private_key']),wallet['public_key'].encode())
    data={'version':1,'address':wallet['address'],'public_key':wallet['public_key'],'salt':base64.b64encode(salt).decode(),'nonce':base64.b64encode(nonce).decode(),'ciphertext':base64.b64encode(ct).decode()}
    with open(path,'w',encoding='utf-8') as f: json.dump(data,f,indent=2)

def load_wallet(path,password):
    with open(path,encoding='utf-8') as f: data=json.load(f)
    private=AESGCM(_key(password,base64.b64decode(data['salt']))).decrypt(base64.b64decode(data['nonce']),base64.b64decode(data['ciphertext']),data['public_key'].encode())
    return {'address':data['address'],'public_key':data['public_key'],'private_key':private.hex(),'password':password}

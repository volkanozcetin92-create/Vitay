# VITAY güvenlik modeli — v2

VITAY bu aşamada **eğitim/testnet yazılımıdır**. "En güvenilir coin" garantisi verilemez; güvenlik, bağımsız kod incelemesi, uzun süreli test, ağ çeşitliliği ve operasyonel güvenlik ile kanıtlanır.

## v2 güvenlik hedefleri
- Ed25519 imzalı transferler
- Deterministik işlem/Blok doğrulaması
- Nonce ile tekrar oynatma koruması
- Maksimum arz ve iki ayrı emisyon havuzu sınırı
- Genesis dağıtımının zincir içinde sabitlenmesi
- Coinbase ödülünün protokol tarafından doğrulanması
- PoW ve blok zaman/önceki-hash kontrolleri
- Blok işlem sayısı ve boyut sınırları
- SQLite WAL + FULL synchronous kalıcılık
- P2P protokol sürümü kontrolü
- İsteğe bağlı `VITAY_PEER_TOKEN` ile node API kimlik doğrulaması

## Üretimden önce zorunlu aşamalar
1. Bağımsız güvenlik denetimi ve kod incelemesi.
2. Fuzz/property-based testler ve uzun süreli node testleri.
3. Testnet üzerinde fork, yeniden başlatma, ağ bölünmesi ve kötü niyetli mesaj testleri.
4. Genesis/consensus kurallarının değişmez bir spesifikasyona bağlanması.
5. Anahtarların çevrimdışı yedeklenmesi ve çoklu imza/erişim politikalarının kurulması.
6. İnternete açık node'larda TLS, firewall, rate-limit ve izleme.
7. Mainnet'e geçmeden önce ayrı bir testnet ve güvenlik ödül programı.

VITAY'ın piyasa değeri, fiyatı veya yatırım getirisi hakkında garanti verilmez.

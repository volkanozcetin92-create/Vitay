"""VITAY Ed25519 signing helpers."""
import hashlib
import json
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives import serialization


def canonical_bytes(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")


def generate_keypair():
    private = Ed25519PrivateKey.generate()
    public = private.public_key()
    private_hex = private.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption()).hex()
    public_hex = public.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw).hex()
    return private_hex, public_hex


def sign(private_hex, message):
    private = Ed25519PrivateKey.from_private_bytes(bytes.fromhex(private_hex))
    return private.sign(message if isinstance(message, bytes) else canonical_bytes(message)).hex()


def verify(public_hex, signature_hex, message):
    try:
        public = Ed25519PublicKey.from_public_bytes(bytes.fromhex(public_hex))
        public.verify(bytes.fromhex(signature_hex), message if isinstance(message, bytes) else canonical_bytes(message))
        return True
    except Exception:
        return False

# VITAY v2.1 — güvenlik geliştirme notları

Bu sürüm hâlâ eğitim/testnet amaçlıdır; bağımsız güvenlik denetimi yapılmadan gerçek para/mainnet kullanımı için hazır kabul edilmemelidir.

## Yapılan iyileştirmeler
- Zincir seçimi yalnızca blok yüksekliğine değil, doğrulanmış PoW iş skoruna göre yapılıyor.
- Peer URL doğrulaması ve peer sayısı sınırı eklendi.
- Mevcut Ed25519, nonce/replay, arz sınırı, PoW, blok boyutu ve SQLite kalıcılığı korundu.
- Tamper testi: imzalı transferin tutarı değiştirildiğinde zincir geçersiz oluyor.

## Sonraki denetim başlıkları
1. Fuzz/property testleri
2. Ağ mesajlarının TLS ve kimlik doğrulaması
3. Peer keşfi ve Sybil dayanıklılığı
4. Mempool ücret/öncelik politikası
5. Reorg ve derin fork testleri
6. Harici bağımsız kod incelemesi

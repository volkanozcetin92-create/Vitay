# VITAY — Solana Devnet Test Package

VITAY çekirdeği ve Solana Devnet test belgeleri/scripts.

Bu paket oluşturulurken zincir üzerinde gerçek mint işlemi yapılmamıştır. Gerçek Devnet işlemi kullanıcı cüzdanı tarafından imzalanmalıdır.

# VITAY — Solana Devnet Test

Eğitim ve test amacıyla Solana Devnet bağlantısı.

## Devnet
```bash
solana config set --url devnet
solana address
solana balance
solana airdrop 2
```

## VITAY mint oluşturma
```bash
spl-token --url devnet create-token --decimals 6
spl-token --url devnet create-account MINT_ADDRESS
spl-token --url devnet mint MINT_ADDRESS 1000
spl-token --url devnet supply MINT_ADDRESS
spl-token --url devnet balance MINT_ADDRESS
```

Toplam arz testi, cüzdan doğrulandıktan sonra yapılmalıdır. Özel anahtar veya seed phrase paylaşmayın.

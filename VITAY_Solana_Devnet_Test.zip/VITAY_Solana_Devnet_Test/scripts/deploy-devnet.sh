#!/usr/bin/env bash
set -euo pipefail
solana config set --url devnet
solana address
solana balance

# Devnet Kontrol Listesi
- [ ] Devnet seçildi
- [ ] Test cüzdanı doğrulandı
- [ ] Test SOL alındı
- [ ] VITAY mint oluşturuldu
- [ ] Token hesabı oluşturuldu
- [ ] Küçük mint testi yapıldı
- [ ] Supply/balance doğrulandı
- [ ] Mint yetkisi ve arz politikası doğrulandı

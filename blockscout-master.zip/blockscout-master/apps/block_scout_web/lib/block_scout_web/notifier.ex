# SPDX-License-Identifier: LicenseRef-Blockscout
defmodule BlockScoutWeb.Notifier do
  @moduledoc """
  Responds to events by sending appropriate channel updates to front-end.

  Every node handles the chain events itself (API nodes receive them from the
  database through `Explorer.Chain.Events.Listener`), so the updates are sent to
  the subscribers of the current node only. Forwarding them to the other nodes
  of the cluster would duplicate the messages there and suspend the handling
  process whenever the distribution buffer to one of those nodes is full.
  """
  use Utils.CompileTimeEnvHelper,
    chain_type: [:explorer, :chain_type],
    chain_identity: [:explorer, :chain_identity]

  use Utils.RuntimeEnvHelper,
    block_broadcast_enrichment_disabled?: [
      :block_scout_web,
      [BlockScoutWeb.Notifier, :block_broadcast_enrichment_disabled]
    ],
    block_broadcast_enrichment_timeout: [
      :block_scout_web,
      [BlockScoutWeb.Notifier, :block_broadcast_enrichment_timeout]
    ]

  require Logger

  alias Absinthe.Subscription

  alias BlockScoutWeb.API.V2, as: API_V2

  alias BlockScoutWeb.API.V2.{
    AddressView,
    BlockView,
    SmartContractView,
    TransactionView
  }

  alias BlockScoutWeb.{
    AddressContractVerificationViaFlattenedCodeView,
    AddressContractVerificationViaJsonView,
    AddressContractVerificationViaMultiPartFilesView,
    AddressContractVerificationViaStandardJsonInputView,
    AddressContractVerificationVyperView,
    Endpoint
  }

  alias Explorer.{Chain, Market, Repo}

  alias Explorer.Chain.{
    Address,
    Address.CoinBalance,
    Address.Reputation,
    Block,
    BlockNumberHelper,
    DenormalizationHelper,
    InternalTransaction,
    Token,
    Token.Instance,
    Transaction
  }

  alias Explorer.Chain.Cache.Counters.{AddressesCount, AverageBlockTime, Helper}
  alias Explorer.Chain.Supply.RSK
  alias Explorer.Chain.Transaction.History.TransactionStats
  alias Explorer.SmartContract.{CompilerVersion, Solidity.CodeCompiler}
  alias Phoenix.View
  alias Timex.Duration

  import Explorer.Chain.Address.MetadataPreloader, only: [maybe_preload_ens_and_metadata: 3]
  import Explorer.Chain.SmartContract.Proxy.Models.Implementation, only: [proxy_implementations_association: 0]

  @check_broadcast_sequence_period 500
  @api_true [api?: true]

  case @chain_type do
    :arbitrum ->
      @chain_type_specific_events ~w(new_arbitrum_batches new_messages_to_arbitrum_amount)a

    :optimism ->
      @chain_type_specific_events ~w(new_optimism_batches new_optimism_deposits)a

    _ ->
      nil
  end

  case @chain_identity do
    {:optimism, :celo} ->
      @chain_type_transaction_associations [
        gas_token: Reputation.reputation_association()
      ]

    _ ->
      @chain_type_transaction_associations []
  end

  # Address-info associations shared by every participant role of a broadcast
  # item. Loaded once per broadcast batch by
  # `Chain.preload_address_participants/4` rather than per role, which repeats
  # each of these queries once per role.
  @participant_necessity_by_association %{
    :scam_badge => :optional,
    :names => :optional,
    proxy_implementations_association() => :optional
  }

  @transaction_address_fields [
    {:from_address_hash, :from_address},
    {:to_address_hash, :to_address},
    {:created_contract_address_hash, :created_contract_address}
  ]

  @token_transfer_address_fields [
    {:from_address_hash, :from_address},
    {:to_address_hash, :to_address}
  ]

  def handle_event({:chain_event, :addresses, type, addresses}) when type in [:realtime, :on_demand] do
    addresses_count = AddressesCount.fetch()

    # TODO: delete duplicated event when old UI becomes deprecated
    Endpoint.local_broadcast("addresses_old:new_address", "count", %{count: addresses_count})
    Endpoint.local_broadcast("addresses:new_address", "count", %{count: addresses_count})

    exchange_rate = Market.get_coin_exchange_rate()

    addresses_with_balance =
      Enum.reject(addresses, fn %Address{fetched_coin_balance: fetched_coin_balance} ->
        is_nil(fetched_coin_balance)
      end)

    addresses_with_balance
    |> Enum.filter(fn %Address{hash: hash} -> address_has_v2_subscribers?(hash) end)
    |> Enum.each(&broadcast_balance_v2(&1, exchange_rate))

    # TODO: delete duplicated event when old UI becomes deprecated
    addresses_with_balance
    |> Enum.filter(fn %Address{hash: hash} -> address_has_old_subscribers?(hash) end)
    |> Enum.each(&broadcast_balance_v1(&1, exchange_rate))
  end

  def handle_event({:chain_event, :address_coin_balances, type, address_coin_balances})
      when type in [:realtime, :on_demand] do
    exchange_rate = Market.get_coin_exchange_rate()

    address_coin_balances
    |> Enum.reject(fn balance -> is_nil(balance[:value]) end)
    # Only the most recent balance of an address is worth a query and a message,
    # the earlier ones are superseded by it right away.
    |> Enum.sort_by(& &1[:block_number], :desc)
    |> Enum.uniq_by(& &1[:address_hash])
    |> Enum.each(&broadcast_address_coin_balance(&1, exchange_rate))
  end

  def handle_event({:chain_event, :address_token_balances, type, address_token_balances})
      when type in [:realtime, :on_demand] do
    address_token_balances
    |> Enum.filter(fn balance -> address_has_v2_subscribers?(balance.address_hash) end)
    |> Enum.each(&broadcast_address_token_balance_v2/1)

    # TODO: delete duplicated event when old UI becomes deprecated
    address_token_balances
    |> Enum.filter(fn balance -> address_has_old_subscribers?(balance.address_hash) end)
    |> Enum.each(&broadcast_address_token_balance_v1/1)
  end

  def handle_event(
        {:chain_event, :contract_verification_result, :on_demand, {address_hash, contract_verification_result}}
      ) do
    log_broadcast_verification_results_for_address(address_hash)
    v2_params = verification_result_params_v2(contract_verification_result)

    # TODO: delete duplicated event when old UI becomes deprecated
    Endpoint.local_broadcast(
      "addresses_old:#{address_hash}",
      "verification_result",
      %{
        result: contract_verification_result
      }
    )

    Endpoint.local_broadcast("addresses:#{address_hash}", "verification_result", v2_params)
  end

  def handle_event(
        {:chain_event, :contract_verification_result, :on_demand, {address_hash, contract_verification_result, conn}}
      ) do
    log_broadcast_verification_results_for_address(address_hash)
    %{view: view, compiler: compiler} = select_contract_type_and_form_view(conn.params)
    v2_params = verification_result_params_v2(contract_verification_result)

    contract_verification_result =
      case contract_verification_result do
        {:ok, _} = result ->
          result

        {:error, changeset} ->
          compiler_versions = fetch_compiler_version(compiler)

          result =
            view
            |> View.render_to_string("new.html",
              changeset: changeset,
              compiler_versions: compiler_versions,
              evm_versions: CodeCompiler.evm_versions(:solidity),
              address_hash: address_hash,
              conn: conn,
              retrying: true
            )

          {:error, result}
      end

    # TODO: delete duplicated event when old UI becomes deprecated
    Endpoint.local_broadcast(
      "addresses_old:#{address_hash}",
      "verification_result",
      %{
        result: contract_verification_result
      }
    )

    Endpoint.local_broadcast("addresses:#{address_hash}", "verification_result", v2_params)
  end

  def handle_event({:chain_event, :block_rewards, :realtime, rewards}) do
    if Application.get_env(:block_scout_web, BlockScoutWeb.Chain)[:has_emission_funds] do
      broadcast_rewards(rewards)
    end
  end

  def handle_event({:chain_event, :blocks, :realtime, blocks}) do
    case Application.get_env(:block_scout_web, __MODULE__)[:block_broadcast_type] do
      :count -> do_handle_blocks_count(blocks)
      _ -> do_handle_blocks(blocks)
    end
  end

  def handle_event({:chain_event, :exchange_rate}) do
    exchange_rate = Market.get_coin_exchange_rate()

    market_history_data =
      Market.fetch_recent_history()
      |> case do
        [today | the_rest] -> [%{today | closing_price: exchange_rate.fiat_value} | the_rest]
        data -> data
      end
      |> Enum.map(fn day -> Map.take(day, [:closing_price, :date]) end)

    exchange_rate_with_available_supply =
      case Application.get_env(:explorer, :supply) do
        RSK ->
          %{exchange_rate | available_supply: nil, market_cap: RSK.market_cap(exchange_rate)}

        _ ->
          Map.from_struct(exchange_rate)
      end

    # TODO: delete duplicated event when old UI becomes deprecated
    Endpoint.local_broadcast("exchange_rate_old:new_rate", "new_rate", %{
      exchange_rate: exchange_rate_with_available_supply,
      market_history_data: market_history_data
    })

    Endpoint.local_broadcast("exchange_rate:new_rate", "new_rate", %{
      exchange_rate: exchange_rate_with_available_supply.fiat_value,
      available_supply: exchange_rate_with_available_supply.available_supply,
      chart_data: market_history_data
    })
  end

  def handle_event(
        {:chain_event, :internal_transactions, :on_demand, [%InternalTransaction{index: 0} = internal_transaction]}
      ) do
    transaction_hash =
      internal_transaction
      |> InternalTransaction.preload_transaction()
      |> Map.get(:transaction_hash)

    # TODO: delete duplicated event when old UI becomes deprecated
    Endpoint.local_broadcast("transactions_old:#{transaction_hash}", "raw_trace", %{raw_trace_origin: transaction_hash})

    internal_transactions = InternalTransaction.all_transaction_to_internal_transactions(transaction_hash)

    v2_params = %{
      raw_trace: TransactionView.render("raw_trace.json", %{internal_transactions: internal_transactions})
    }

    Endpoint.local_broadcast("transactions:#{transaction_hash}", "raw_trace", v2_params)
  end

  # internal transactions broadcast disabled on the indexer level, therefore it out of scope of the refactoring within https://github.com/blockscout/blockscout/pull/7474
  def handle_event({:chain_event, :internal_transactions, :realtime, internal_transactions}) do
    internal_transactions
    |> Stream.filter(fn it ->
      address_has_subscribers?(it.from_address_hash) or
        address_has_subscribers?(it.to_address_hash)
    end)
    |> Stream.map(
      &(InternalTransaction.where_nonpending_operation()
        |> Repo.get_by(block_number: &1.block_number, transaction_index: &1.transaction_index, index: &1.index)
        |> Repo.preload([:block])
        |> InternalTransaction.preload_addresses()
        |> InternalTransaction.preload_transaction())
    )
    |> Enum.each(&broadcast_internal_transaction/1)
  end

  def handle_event({:chain_event, :token_transfers, :realtime, all_token_transfers}) do
    all_transfers_by_token =
      Enum.group_by(all_token_transfers, fn tt -> to_string(tt.token_contract_address_hash) end)

    for {token_contract_address_hash, token_transfers} <- all_transfers_by_token do
      # Local only, like the channel updates (see the moduledoc)
      Subscription.Local.publish_mutation(
        Endpoint,
        token_transfers,
        token_transfers: token_contract_address_hash
      )
    end

    relevant_transfers = Enum.filter(all_token_transfers, &token_transfer_has_subscribers?/1)

    if relevant_transfers != [] do
      all_token_transfers_full =
        relevant_transfers
        |> Repo.preload(
          DenormalizationHelper.extend_transaction_preload([
            [token: Reputation.reputation_association()],
            :transaction
          ])
        )
        |> preload_participants(@token_transfer_address_fields)
        |> Instance.preload_nft(@api_true)

      broadcast_token_transfers_websocket_v2(all_token_transfers_full)

      # TODO: delete duplicated event when old UI becomes deprecated
      broadcast_token_transfers_websocket_v1(all_token_transfers_full)
    end
  end

  def handle_event({:chain_event, :transactions, :realtime, transactions}) do
    broadcast_transactions_websocket_v2(transactions)

    # TODO: delete duplicated event when old UI becomes deprecated
    broadcast_transactions_websocket_v1(transactions)
  end

  def handle_event({:chain_event, :transaction_stats}) do
    today = Date.utc_today()

    [{:history_size, history_size}] =
      Application.get_env(:block_scout_web, BlockScoutWeb.Chain.TransactionHistoryChartController, {:history_size, 30})

    x_days_back = Date.add(today, -1 * history_size)

    date_range = TransactionStats.by_date_range(x_days_back, today)
    stats = Enum.map(date_range, fn item -> Map.drop(item, [:__meta__]) end)

    Endpoint.local_broadcast("transactions_old:stats", "update", %{stats: stats})
  end

  def handle_event(
        {:chain_event, :token_total_supply, :on_demand,
         [%Token{contract_address_hash: contract_address_hash, total_supply: total_supply} = token]}
      )
      when not is_nil(total_supply) do
    # TODO: delete duplicated event when old UI becomes deprecated
    Endpoint.local_broadcast("tokens_old:#{to_string(contract_address_hash)}", "token_total_supply", %{token: token})

    Endpoint.local_broadcast("tokens:#{to_string(contract_address_hash)}", "total_supply", %{
      total_supply: to_string(total_supply)
    })
  end

  def handle_event({:chain_event, :fetched_bytecode, :on_demand, [address_hash, fetched_bytecode]}) do
    # TODO: delete duplicated event when old UI becomes deprecated
    Endpoint.local_broadcast("addresses_old:#{to_string(address_hash)}", "fetched_bytecode", %{
      fetched_bytecode: fetched_bytecode
    })

    Endpoint.local_broadcast("addresses:#{to_string(address_hash)}", "fetched_bytecode", %{
      fetched_bytecode: fetched_bytecode
    })
  end

  def handle_event(
        {:chain_event, :fetched_token_instance_metadata, :on_demand,
         [token_contract_address_hash_string, token_id, fetched_token_instance_metadata]}
      ) do
    Endpoint.local_broadcast(
      "token_instances:#{token_contract_address_hash_string}",
      "fetched_token_instance_metadata",
      %{token_id: to_string(token_id), fetched_metadata: fetched_token_instance_metadata}
    )
  end

  def handle_event(
        {:chain_event, :not_fetched_token_instance_metadata, :on_demand,
         [token_contract_address_hash_string, token_id, reason]}
      ) do
    Endpoint.local_broadcast(
      "token_instances:#{token_contract_address_hash_string}",
      "not_fetched_token_instance_metadata",
      %{token_id: to_string(token_id), reason: reason}
    )
  end

  def handle_event({:chain_event, :changed_bytecode, :on_demand, [address_hash]}) do
    # TODO: delete duplicated event when old UI becomes deprecated
    Endpoint.local_broadcast("addresses_old:#{to_string(address_hash)}", "changed_bytecode", %{})
    Endpoint.local_broadcast("addresses:#{to_string(address_hash)}", "changed_bytecode", %{})
  end

  def handle_event({:chain_event, :smart_contract_was_verified = event, :on_demand, [address_hash]}) do
    broadcast_automatic_verification_events(event, address_hash)
  end

  def handle_event({:chain_event, :smart_contract_was_not_verified = event, :on_demand, [address_hash]}) do
    broadcast_automatic_verification_events(event, address_hash)
  end

  def handle_event({:chain_event, :eth_bytecode_db_lookup_started = event, :on_demand, [address_hash]}) do
    broadcast_automatic_verification_events(event, address_hash)
  end

  @current_token_balances_limit 50
  def handle_event({:chain_event, :address_current_token_balances, type, address_current_token_balances})
      when type in [:realtime, :on_demand] do
    address_current_token_balances
    |> Enum.filter(&address_has_subscribers?(&1.address_hash))
    |> Repo.preload(token: Reputation.reputation_association())
    |> Enum.group_by(& &1.address_hash)
    |> Enum.each(fn {address_hash, balances} ->
      balances
      |> Enum.group_by(& &1.token_type)
      |> Enum.each(fn {token_type, token_type_balances} ->
        broadcast_token_balances(address_hash, token_type, token_type_balances)
      end)
    end)
  end

  case @chain_type do
    :arbitrum ->
      def handle_event({:chain_event, topic, _, _} = event) when topic in @chain_type_specific_events,
        # credo:disable-for-next-line Credo.Check.Design.AliasUsage
        do: BlockScoutWeb.Notifiers.Arbitrum.handle_event(event)

    :optimism ->
      def handle_event({:chain_event, topic, _, _} = event) when topic in @chain_type_specific_events,
        # credo:disable-for-next-line Credo.Check.Design.AliasUsage
        do: BlockScoutWeb.Notifiers.Optimism.handle_event(event)

    _ ->
      nil
  end

  def handle_event(event) do
    Logger.warning("Unknown broadcasted event #{inspect(event)}.")
    nil
  end

  defp do_handle_blocks_count(blocks) do
    blocks
    |> Enum.group_by(&(&1 |> BlockScoutWeb.BlockView.block_type() |> String.downcase()))
    |> Enum.each(fn {type, blocks_list} ->
      Endpoint.local_broadcast("blocks:new_block", "new_blocks_count", %{count: Enum.count(blocks_list), type: type})
    end)
  end

  defp do_handle_blocks(blocks) do
    blocks =
      blocks
      |> Enum.sort_by(& &1.number, :asc)
      |> preload_blocks_for_broadcast()

    # The previous block number is a lookup of null rounds on Filecoin, so it is resolved for the whole batch at once
    previous_block_numbers = blocks |> Enum.map(& &1.number) |> BlockNumberHelper.previous_block_numbers()

    Enum.each(blocks, fn block ->
      last_broadcasted_block_number = Helper.fetch_from_ets_cache(:last_broadcasted_block, :number)
      broadcast_latest_block?(block, last_broadcasted_block_number, previous_block_numbers[block.number])
    end)
  end

  def fetch_compiler_version(compiler) do
    case CompilerVersion.fetch_versions(compiler) do
      {:ok, compiler_versions} ->
        compiler_versions

      {:error, _} ->
        []
    end
  end

  def select_contract_type_and_form_view(params) do
    verification_from_metadata_json? = check_verification_type(params, "json:metadata")

    verification_from_standard_json_input? = check_verification_type(params, "json:standard")

    verification_from_vyper? = check_verification_type(params, "vyper")

    verification_from_multi_part_files? = check_verification_type(params, "multi-part-files")

    compiler = if verification_from_vyper?, do: :vyper, else: :solc

    view =
      cond do
        verification_from_standard_json_input? -> AddressContractVerificationViaStandardJsonInputView
        verification_from_metadata_json? -> AddressContractVerificationViaJsonView
        verification_from_vyper? -> AddressContractVerificationVyperView
        verification_from_multi_part_files? -> AddressContractVerificationViaMultiPartFilesView
        true -> AddressContractVerificationViaFlattenedCodeView
      end

    %{view: view, compiler: compiler}
  end

  # credo:disable-for-next-line Credo.Check.Refactor.CyclomaticComplexity
  defp broadcast_token_balances(address_hash, token_type, balances) do
    sorted =
      Enum.sort_by(
        balances,
        fn ctb ->
          case ctb.token do
            %Token{decimals: decimals, fiat_value: fiat_value} when not is_nil(decimals) ->
              value = Decimal.div(ctb.value, Decimal.new(Integer.pow(10, Decimal.to_integer(decimals))))
              {(fiat_value && Decimal.mult(value, fiat_value)) || Decimal.new(0), value}

            _ ->
              {Decimal.new(0), ctb.value}
          end
        end,
        fn {fiat_value_1, value_1}, {fiat_value_2, value_2} ->
          case {Decimal.compare(fiat_value_1, fiat_value_2), Decimal.compare(value_1, value_2)} do
            {:gt, _} -> true
            {:eq, :gt} -> true
            {:eq, :eq} -> true
            _ -> false
          end
        end
      )

    event_postfix =
      token_type
      |> String.downcase()
      |> String.replace("-", "_")

    event = "updated_token_balances_" <> event_postfix

    Endpoint.local_broadcast("addresses:#{address_hash}", event, %{
      token_balances:
        AddressView.render("token_balances.json", %{
          token_balances: Enum.take(sorted, @current_token_balances_limit)
        }),
      overflow: Enum.count(sorted) > @current_token_balances_limit
    })
  end

  defp verification_result_params_v2({:ok, _contract}) do
    %{status: "success"}
  end

  defp verification_result_params_v2({:error, changeset}) do
    %{
      status: "error",
      errors: SmartContractView.render("changeset_errors.json", %{changeset: changeset})
    }
  end

  defp check_verification_type(params, type),
    do: Map.has_key?(params, "verification_type") && Map.get(params, "verification_type") == type

  @doc """
  Broadcast the percentage of blocks or pending block operations indexed so far.
  """
  @spec broadcast_indexed_ratio(String.t(), Decimal.t()) ::
          :ok | {:error, term()}
  def broadcast_indexed_ratio(msg, ratio) do
    Endpoint.local_broadcast(msg, "index_status", %{
      ratio: Decimal.to_string(ratio),
      finished: Chain.finished_indexing_from_ratio?(ratio)
    })
  end

  defp broadcast_latest_block?(block, last_broadcasted_block_number, previous_block_number) do
    cond do
      last_broadcasted_block_number == 0 ||
        last_broadcasted_block_number == previous_block_number ||
          last_broadcasted_block_number < block.number - 4 ->
        broadcast_block(block)
        :ets.insert(:last_broadcasted_block, {:number, block.number})

      last_broadcasted_block_number > previous_block_number ->
        broadcast_block(block)

      true ->
        Task.start_link(fn ->
          schedule_broadcasting(block, previous_block_number)
        end)
    end
  end

  defp schedule_broadcasting(block, previous_block_number) do
    :timer.sleep(@check_broadcast_sequence_period)
    last_broadcasted_block_number = Helper.fetch_from_ets_cache(:last_broadcasted_block, :number)

    if last_broadcasted_block_number == previous_block_number do
      broadcast_block(block)
      :ets.insert(:last_broadcasted_block, {:number, block.number})
    else
      schedule_broadcasting(block, previous_block_number)
    end
  end

  # Subscribers of both channels are checked here rather than filtered upstream:
  # the coin balance query below feeds both payloads, so it has to run once for
  # an address subscribed to either of them.
  defp broadcast_address_coin_balance(%{address_hash: address_hash, block_number: block_number}, exchange_rate) do
    old_subscribers? = address_has_old_subscribers?(address_hash)
    v2_subscribers? = address_has_v2_subscribers?(address_hash)

    coin_balance =
      if old_subscribers? or v2_subscribers?,
        do: CoinBalance.get_coin_balance(address_hash, block_number, @api_true)

    if coin_balance && coin_balance.delta && !Decimal.eq?(coin_balance.delta, Decimal.new(0)) do
      # TODO: delete duplicated event when old UI becomes deprecated
      if old_subscribers? do
        Endpoint.local_broadcast("addresses_old:#{address_hash}", "coin_balance", %{
          block_number: block_number,
          coin_balance: coin_balance
        })
      end

      if v2_subscribers? and coin_balance.value do
        broadcast_address_coin_balance_v2(address_hash, block_number, coin_balance, exchange_rate)
      end
    end
  end

  defp broadcast_address_coin_balance_v2(address_hash, block_number, coin_balance, exchange_rate) do
    rendered_coin_balance = AddressView.render("coin_balance.json", %{coin_balance: coin_balance})

    Endpoint.local_broadcast("addresses:#{address_hash}", "coin_balance", %{
      coin_balance: rendered_coin_balance
    })

    Endpoint.local_broadcast("addresses:#{address_hash}", "current_coin_balance", %{
      coin_balance: coin_balance.value,
      exchange_rate: exchange_rate.fiat_value,
      block_number: block_number
    })
  end

  defp broadcast_address_token_balance_v2(%{address_hash: address_hash, block_number: block_number}) do
    Endpoint.local_broadcast("addresses:#{address_hash}", "token_balance", %{
      block_number: block_number
    })
  end

  # TODO: delete this function when old UI becomes deprecated
  defp broadcast_address_token_balance_v1(%{address_hash: address_hash, block_number: block_number}) do
    Endpoint.local_broadcast("addresses_old:#{address_hash}", "token_balance", %{
      block_number: block_number
    })
  end

  defp broadcast_balance_v2(%Address{hash: address_hash} = address, exchange_rate) do
    Endpoint.local_broadcast("addresses:#{address_hash}", "balance", %{
      balance: address.fetched_coin_balance.value,
      block_number: address.fetched_coin_balance_block_number,
      exchange_rate: exchange_rate.fiat_value
    })
  end

  # TODO: delete this function when old UI becomes deprecated
  defp broadcast_balance_v1(%Address{hash: address_hash} = address, exchange_rate) do
    Endpoint.local_broadcast(
      "addresses_old:#{address_hash}",
      "balance_update",
      %{
        address: address,
        exchange_rate: exchange_rate
      }
    )
  end

  defp preload_blocks_for_broadcast(blocks) do
    blocks
    |> Repo.preload([
      [miner: [:names, :smart_contract, proxy_implementations_association()]],
      :transactions,
      :rewards
    ])
    |> Block.preload_eip1559_config()
    # TODO: the enrichment holds the broadcast of the whole batch back for up to
    # its timeout, consider broadcasting the enrichment data separately
    |> maybe_preload_enrichment_for_broadcast()
  end

  defp broadcast_block(preloaded_block) do
    average_block_time = AverageBlockTime.average_block_time()

    # TODO: delete duplicated event when old UI becomes deprecated
    Endpoint.local_broadcast("blocks_old:new_block", "new_block", %{
      block: preloaded_block,
      average_block_time: average_block_time
    })

    Endpoint.local_broadcast("blocks_old:#{to_string(preloaded_block.miner_hash)}", "new_block", %{
      block: preloaded_block,
      average_block_time: average_block_time
    })

    block_params_v2 = %{
      average_block_time: to_string(Duration.to_milliseconds(average_block_time)),
      block:
        BlockView.render("block.json", %{
          block: preloaded_block,
          socket: nil
        })
    }

    Endpoint.local_broadcast("blocks:new_block", "new_block", block_params_v2)
    Endpoint.local_broadcast("blocks:#{to_string(preloaded_block.miner_hash)}", "new_block", block_params_v2)
  end

  defp maybe_preload_enrichment_for_broadcast(blocks) do
    if block_broadcast_enrichment_disabled?() do
      blocks
    else
      # The timeout is per miner, and a single request asks about all miners of the batch
      miners_count = blocks |> Enum.uniq_by(& &1.miner_hash) |> Enum.count()

      maybe_preload_ens_and_metadata(blocks, :blocks, timeout: block_broadcast_enrichment_timeout() * miners_count)
    end
  end

  defp broadcast_rewards(rewards) do
    {emission_rewards, validator_rewards} =
      Enum.split_with(rewards, fn reward -> reward.address_type == :emission_funds end)

    Enum.each(validator_rewards, fn reward ->
      Endpoint.local_broadcast("rewards:#{to_string(reward.address_hash)}", "new_reward", %{reward: 1})
    end)

    # TODO: delete duplicated event when old UI becomes deprecated
    broadcast_rewards_v1(validator_rewards, emission_rewards)
  end

  # TODO: delete this function when old UI becomes deprecated
  defp broadcast_rewards_v1(validator_rewards, emission_rewards) do
    case Enum.filter(validator_rewards, &reward_has_old_subscribers?/1) do
      [] ->
        :ok

      relevant_rewards ->
        emission_reward = emission_rewards |> Repo.preload([:address, :block]) |> List.first()

        relevant_rewards
        |> Repo.preload([:address, :block])
        |> Enum.each(fn reward ->
          Endpoint.local_broadcast("rewards_old:#{to_string(reward.address_hash)}", "new_reward", %{
            emission_funds: emission_reward,
            validator: reward
          })
        end)
    end
  end

  defp broadcast_internal_transaction(internal_transaction) do
    Endpoint.local_broadcast("addresses_old:#{internal_transaction.from_address_hash}", "internal_transaction", %{
      address: internal_transaction.from_address,
      internal_transaction: internal_transaction
    })

    if internal_transaction.to_address_hash != internal_transaction.from_address_hash do
      Endpoint.local_broadcast("addresses_old:#{internal_transaction.to_address_hash}", "internal_transaction", %{
        address: internal_transaction.to_address,
        internal_transaction: internal_transaction
      })
    end
  end

  defp broadcast_transactions_websocket_v2(transactions) do
    {pending_transactions, validated_transactions} =
      Enum.split_with(transactions, fn
        %Transaction{block_number: nil} -> true
        _ -> false
      end)

    broadcast_transactions_websocket_v2_inner(
      pending_transactions,
      "transactions:new_pending_transaction",
      "pending_transaction"
    )

    broadcast_transactions_websocket_v2_inner(validated_transactions, "transactions:new_transaction", "transaction")
  end

  defp broadcast_transactions_websocket_v2_inner(transactions, default_channel, event) do
    if not Enum.empty?(transactions) do
      Endpoint.local_broadcast(default_channel, event, %{
        String.to_existing_atom(event) => Enum.count(transactions)
      })
    end

    case Enum.filter(transactions, &transaction_has_subscribers?/1) do
      [] ->
        :ok

      relevant_transactions ->
        prepared_transactions =
          TransactionView.render("transactions.json", %{
            transactions:
              relevant_transactions
              |> Repo.preload(transaction_broadcast_associations())
              |> preload_participants(@transaction_address_fields),
            conn: nil
          })

        relevant_transactions
        |> Enum.zip(prepared_transactions)
        |> group_by_address_hashes_and_broadcast(event, :transactions, & &1["hash"])
    end
  end

  # TODO: delete this function when old UI becomes deprecated
  defp broadcast_transactions_websocket_v1(transactions) do
    relevant_transactions =
      if has_subscribers?("transactions_old:new_transaction") or
           has_subscribers?("transactions_old:new_pending_transaction") do
        transactions
      else
        Enum.filter(transactions, &transaction_has_old_subscribers?/1)
      end

    if relevant_transactions != [] do
      relevant_transactions
      |> Repo.preload([:block | @chain_type_transaction_associations])
      |> preload_participants(@transaction_address_fields)
      |> Enum.map(fn transaction ->
        Map.put(transaction, :token_transfers, [])
      end)
      |> Enum.each(&broadcast_transaction/1)
    end
  end

  defp transaction_broadcast_associations do
    if API_V2.enabled?(),
      do: [
        :block,
        {:token_transfers, [token: Reputation.reputation_association()]} | @chain_type_transaction_associations
      ],
      else: [:block | @chain_type_transaction_associations]
  end

  # Loads the address info of every participant of the broadcast batch in one
  # pass, deduplicating addresses shared between items and between roles of the
  # same item. Broadcasts run off the primary repo, as the preloads they replace
  # did.
  defp preload_participants(items, address_fields) do
    Chain.preload_address_participants(items, address_fields, @participant_necessity_by_association, [])
  end

  defp broadcast_transaction(%Transaction{block_number: nil} = pending) do
    broadcast_transaction(pending, "transactions_old:new_pending_transaction", "pending_transaction")
  end

  defp broadcast_transaction(transaction) do
    broadcast_transaction(transaction, "transactions_old:new_transaction", "transaction")
  end

  defp broadcast_transaction(transaction, transaction_channel, event) do
    Endpoint.local_broadcast("transactions_old:#{transaction.hash}", "collated", %{})

    Endpoint.local_broadcast(transaction_channel, event, %{
      transaction: transaction
    })

    Endpoint.local_broadcast("addresses_old:#{transaction.from_address_hash}", event, %{
      address: transaction.from_address,
      transaction: transaction
    })

    if transaction.to_address_hash != transaction.from_address_hash do
      Endpoint.local_broadcast("addresses_old:#{transaction.to_address_hash}", event, %{
        address: transaction.to_address,
        transaction: transaction
      })
    end
  end

  defp broadcast_token_transfers_websocket_v2(tokens_transfers) do
    case Enum.filter(tokens_transfers, &token_transfer_has_v2_subscribers?/1) do
      [] ->
        :ok

      relevant_token_transfers ->
        for {token_contract_address_hash, token_transfers} <-
              Enum.group_by(relevant_token_transfers, fn tt -> to_string(tt.token_contract_address_hash) end) do
          Endpoint.local_broadcast("tokens:#{token_contract_address_hash}", "token_transfer", %{
            token_transfer: Enum.count(token_transfers)
          })
        end

        prepared_token_transfers =
          TransactionView.render("token_transfers.json", %{
            token_transfers: relevant_token_transfers,
            conn: nil
          })

        relevant_token_transfers
        |> Enum.zip(prepared_token_transfers)
        |> group_by_address_hashes_and_broadcast(
          "token_transfer",
          :token_transfers,
          &{&1["transaction_hash"], &1["block_hash"], &1["log_index"]}
        )
    end
  end

  # TODO: delete this function when old UI becomes deprecated
  defp broadcast_token_transfers_websocket_v1(tokens_transfers) do
    tokens_transfers
    |> Enum.filter(&token_transfer_has_old_subscribers?/1)
    |> Enum.each(&broadcast_token_transfer/1)
  end

  defp broadcast_token_transfer(token_transfer) do
    broadcast_token_transfer(token_transfer, "token_transfer")
  end

  defp broadcast_token_transfer(token_transfer, event) do
    Endpoint.local_broadcast("addresses_old:#{token_transfer.from_address_hash}", event, %{
      address: token_transfer.from_address,
      token_transfer: token_transfer
    })

    Endpoint.local_broadcast("tokens_old:#{token_transfer.token_contract_address_hash}", event, %{
      address: token_transfer.token_contract_address_hash,
      token_transfer: token_transfer
    })

    if token_transfer.to_address_hash != token_transfer.from_address_hash do
      Endpoint.local_broadcast("addresses_old:#{token_transfer.to_address_hash}", event, %{
        address: token_transfer.to_address,
        token_transfer: token_transfer
      })
    end
  end

  defp group_by_address_hashes_and_broadcast(elements, event, map_key, uniq_function) do
    grouped_by_from =
      elements
      |> Enum.group_by(fn {el, _} -> el.from_address_hash end, fn {_, prepared_el} -> prepared_el end)

    grouped_by_to =
      elements
      |> Enum.group_by(fn {el, _} -> el.to_address_hash end, fn {_, prepared_el} -> prepared_el end)

    grouped = Map.merge(grouped_by_to, grouped_by_from, fn _k, v1, v2 -> Enum.uniq_by(v1 ++ v2, uniq_function) end)

    for {address_hash, elements} <- grouped do
      Endpoint.local_broadcast("addresses:#{address_hash}", event, %{map_key => elements})
    end
  end

  defp log_broadcast_verification_results_for_address(address_hash) do
    Logger.info("Broadcast smart-contract #{address_hash} verification results")
  end

  defp log_broadcast_smart_contract_event(address_hash, event) do
    Logger.info("Broadcast smart-contract #{address_hash}: #{event}")
  end

  defp broadcast_automatic_verification_events(event, address_hash) do
    log_broadcast_smart_contract_event(address_hash, event)
    # TODO: delete duplicated event when old UI becomes deprecated
    Endpoint.local_broadcast("addresses_old:#{to_string(address_hash)}", to_string(event), %{})
    Endpoint.local_broadcast("addresses:#{to_string(address_hash)}", to_string(event), %{})
  end

  defp has_subscribers?(topic) when is_binary(topic) do
    Registry.lookup(BlockScoutWeb.PubSub, topic) != []
  end

  defp address_has_subscribers?(nil), do: false

  defp address_has_subscribers?(address_hash) do
    address_has_v2_subscribers?(address_hash) or
      address_has_old_subscribers?(address_hash)
  end

  defp address_has_v2_subscribers?(nil), do: false

  defp address_has_v2_subscribers?(address_hash) do
    has_subscribers?("addresses:" <> to_string(address_hash))
  end

  # TODO: delete this function when old UI becomes deprecated
  defp address_has_old_subscribers?(nil), do: false

  defp address_has_old_subscribers?(address_hash) do
    has_subscribers?("addresses_old:" <> to_string(address_hash))
  end

  # TODO: delete this function when old UI becomes deprecated
  defp reward_has_old_subscribers?(reward) do
    has_subscribers?("rewards_old:" <> to_string(reward.address_hash))
  end

  defp token_transfer_has_subscribers?(tt) do
    token_transfer_has_v2_subscribers?(tt) or
      token_transfer_has_old_subscribers?(tt)
  end

  defp token_transfer_has_v2_subscribers?(tt) do
    address_has_v2_subscribers?(tt.from_address_hash) or
      address_has_v2_subscribers?(tt.to_address_hash) or
      token_has_v2_subscribers?(tt.token_contract_address_hash)
  end

  # TODO: delete this function when old UI becomes deprecated
  defp token_transfer_has_old_subscribers?(tt) do
    address_has_old_subscribers?(tt.from_address_hash) or
      address_has_old_subscribers?(tt.to_address_hash) or
      token_has_old_subscribers?(tt.token_contract_address_hash)
  end

  defp token_has_v2_subscribers?(nil), do: false

  defp token_has_v2_subscribers?(token_address_hash) do
    has_subscribers?("tokens:" <> to_string(token_address_hash))
  end

  # TODO: delete this function when old UI becomes deprecated
  defp token_has_old_subscribers?(nil), do: false

  defp token_has_old_subscribers?(token_address_hash) do
    has_subscribers?("tokens_old:" <> to_string(token_address_hash))
  end

  defp transaction_has_subscribers?(transaction) do
    address_has_subscribers?(transaction.from_address_hash) or
      address_has_subscribers?(transaction.to_address_hash) or
      address_has_subscribers?(transaction.created_contract_address_hash)
  end

  # TODO: delete this function when old UI becomes deprecated
  defp transaction_has_old_subscribers?(transaction) do
    has_subscribers?("transactions_old:" <> to_string(transaction.hash)) or
      address_has_old_subscribers?(transaction.from_address_hash) or
      address_has_old_subscribers?(transaction.to_address_hash)
  end
end

# SPDX-License-Identifier: LicenseRef-Blockscout
defmodule BlockScoutWeb.TransactionController do
  use BlockScoutWeb, :controller

  import BlockScoutWeb.Account.AuthController, only: [current_user: 1]
  import BlockScoutWeb.Models.GetAddressTags, only: [get_address_tags: 2]
  import BlockScoutWeb.Models.GetTransactionTags, only: [get_transaction_with_addresses_tags: 2]

  alias BlockScoutWeb.{
    AccessHelper,
    Controller,
    TransactionInternalTransactionController,
    TransactionTokenTransferController,
    TransactionView
  }

  alias Explorer.{Chain, Market}
  alias Explorer.Chain.Cache.Counters.TransactionsCount
  alias Explorer.Chain.Transaction

  @necessity_by_association %{
    :block => :optional,
    [created_contract_address: :names] => :optional,
    [from_address: :names] => :optional,
    [to_address: :names] => :optional,
    [to_address: :smart_contract] => :optional,
    :token_transfers => :optional
  }

  def index(conn, _params) do
    transaction_estimated_count = TransactionsCount.get()

    render(
      conn,
      "index.html",
      current_path: Controller.current_full_path(conn),
      transaction_estimated_count: transaction_estimated_count
    )
  end

  def show(conn, %{"id" => transaction_hash_string, "type" => "JSON"}) do
    case Chain.string_to_full_hash(transaction_hash_string) do
      {:ok, transaction_hash} ->
        if Chain.transaction_has_token_transfers?(transaction_hash) do
          TransactionTokenTransferController.index(conn, %{
            "transaction_id" => transaction_hash_string,
            "type" => "JSON"
          })
        else
          TransactionInternalTransactionController.index(conn, %{
            "transaction_id" => transaction_hash_string,
            "type" => "JSON"
          })
        end

      :error ->
        set_not_found_view(conn, transaction_hash_string)
    end
  end

  def show(conn, %{"id" => id} = params) do
    with {:ok, transaction_hash} <- Chain.string_to_full_hash(id),
         :ok <- Transaction.check_transaction_exists(transaction_hash) do
      render_transaction_page(conn, id, transaction_hash, params)
    else
      :error ->
        unprocessable_entity(conn)

      :not_found ->
        set_not_found_view(conn, id)
    end
  end

  defp render_transaction_page(conn, id, transaction_hash, params) do
    show_token_transfers? = Chain.transaction_has_token_transfers?(transaction_hash)

    template =
      if show_token_transfers? do
        "show_token_transfers.html"
      else
        "show_internal_transactions.html"
      end

    with {:ok, transaction} <-
           Chain.hash_to_transaction(transaction_hash, necessity_by_association: @necessity_by_association),
         {:ok, false} <- AccessHelper.restricted_access?(to_string(transaction.from_address_hash), params),
         {:ok, false} <- AccessHelper.restricted_access?(to_string(transaction.to_address_hash), params) do
      render(
        conn,
        template,
        exchange_rate: Market.get_coin_exchange_rate(),
        block_height: Chain.block_height(),
        current_path: Controller.current_full_path(conn),
        current_user: current_user(conn),
        show_token_transfers: show_token_transfers?,
        transaction: transaction,
        from_tags: get_address_tags(transaction.from_address_hash, current_user(conn)),
        to_tags: get_address_tags(transaction.to_address_hash, current_user(conn)),
        transaction_tags: get_transaction_with_addresses_tags(transaction, current_user(conn))
      )
    else
      {:error, :not_found} ->
        set_not_found_view(conn, id)

      {:restricted_access, _} ->
        set_not_found_view(conn, id)
    end
  end

  def set_not_found_view(conn, transaction_hash_string) do
    conn
    |> put_status(404)
    |> put_view(TransactionView)
    |> render("not_found.html", transaction_hash: transaction_hash_string)
  end
end

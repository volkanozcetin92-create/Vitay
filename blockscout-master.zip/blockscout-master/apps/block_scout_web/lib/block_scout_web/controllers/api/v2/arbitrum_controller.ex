# SPDX-License-Identifier: LicenseRef-Blockscout
defmodule BlockScoutWeb.API.V2.ArbitrumController do
  use BlockScoutWeb, :controller
  use OpenApiSpex.ControllerSpecs

  import BlockScoutWeb.Chain,
    only: [
      next_page_params: 5,
      paging_options: 1,
      split_list_by_page: 1,
      parse_block_hash_or_number_param: 1
    ]

  import Explorer.Chain.Arbitrum.DaMultiPurposeRecord.Helper, only: [calculate_celestia_data_key: 2]

  alias BlockScoutWeb.Schemas.API.V2.ErrorResponses.BadRequestResponse
  alias BlockScoutWeb.Schemas.API.V2.ErrorResponses.NotFoundResponse
  alias Explorer.Arbitrum.ClaimRollupMessage
  alias Explorer.Chain.Arbitrum.{L1Batch, Message}
  alias Explorer.Chain.Hash
  alias Explorer.PagingOptions

  alias Explorer.Chain.Arbitrum.Reader.API.Messages, as: MessagesReader
  alias Explorer.Chain.Arbitrum.Reader.API.Settlement, as: SettlementReader

  action_fallback(BlockScoutWeb.API.V2.FallbackController)

  plug(OpenApiSpex.Plug.CastAndValidate, json_render_error_v2: true)

  tags(["arbitrum"])

  @batch_necessity_by_association %{:commitment_transaction => :required}

  @direction_param %OpenApiSpex.Parameter{
    name: :direction,
    in: :path,
    required: true,
    schema: %Schema{type: :string, enum: ["from-rollup", "to-rollup"]},
    description: "Message direction: `from-rollup` for Rollup to Parent chain, `to-rollup` for Parent chain to Rollup."
  }

  operation :messages,
    summary: "List cross-chain messages.",
    description: "Retrieves a paginated list of Arbitrum cross-chain messages filtered by the specified direction.",
    parameters: [@direction_param | base_params()] ++ define_paging_params(["id", "items_count"]),
    responses: [
      ok:
        {"Paginated list of cross-chain messages.", "application/json",
         paginated_response(
           items: Schemas.Arbitrum.Message,
           next_page_params_example: %{"id" => 123}
         )},
      unprocessable_entity: JsonErrorResponse.response()
    ]

  operation :messages_count,
    summary: "Get cross-chain messages count.",
    description: "Retrieves the total count of Arbitrum cross-chain messages for the specified direction.",
    parameters: [@direction_param | base_params()],
    responses: [
      ok:
        {"Total count of cross-chain messages for the specified direction.", "application/json",
         %Schema{type: :integer, minimum: 0}},
      unprocessable_entity: JsonErrorResponse.response()
    ]

  operation :claim_message,
    summary: "Get claim data for a withdrawal.",
    description:
      "Returns the ABI-encoded calldata and outbox contract address required to execute a Rollup withdrawal on the Parent chain.",
    parameters: [
      %OpenApiSpex.Parameter{
        name: :message_id,
        in: :path,
        schema: %Schema{type: :integer, minimum: 0},
        required: true,
        description: "Withdrawal message ID."
      }
      | base_params()
    ],
    responses: [
      ok: {"Claim data for the withdrawal.", "application/json", Schemas.Arbitrum.ClaimMessage},
      bad_request:
        {"Withdrawal cannot be claimed. Returned when the withdrawal is unconfirmed, just initiated, or already executed.",
         "application/json", BadRequestResponse},
      not_found: NotFoundResponse.response(),
      unprocessable_entity: JsonErrorResponse.response()
    ]

  operation :withdrawals,
    summary: "Get withdrawal messages for a transaction.",
    description: "Returns the list of Rollup withdrawal messages (L2ToL1Tx events) emitted by the given transaction.",
    parameters: [
      %OpenApiSpex.Parameter{
        name: :transaction_hash,
        in: :path,
        schema: Schemas.General.FullHash,
        required: true,
        description: "Transaction hash."
      }
      | base_params()
    ],
    responses: [
      ok:
        {"Withdrawal messages for the transaction.", "application/json",
         %OpenApiSpex.Schema{
           type: :object,
           properties: %{
             items: %OpenApiSpex.Schema{type: :array, items: Schemas.Arbitrum.Withdrawal}
           },
           required: [:items],
           additionalProperties: false
         }},
      unprocessable_entity: JsonErrorResponse.response()
    ]

  operation :batch,
    summary: "Get batch by number.",
    description: "Retrieves detailed information about an Arbitrum batch by its number.",
    parameters: [
      %OpenApiSpex.Parameter{
        name: :batch_number,
        in: :path,
        schema: %Schema{type: :integer, minimum: 0},
        required: true,
        description: "Batch number."
      }
      | base_params()
    ],
    responses: [
      ok: {"Batch info.", "application/json", Schemas.Arbitrum.Batch},
      not_found: NotFoundResponse.response(),
      unprocessable_entity: JsonErrorResponse.response()
    ]

  operation :batch_by_anytrust_da_info,
    summary: "Get batch by AnyTrust data hash.",
    description:
      "Retrieves an Arbitrum batch associated with the given AnyTrust data hash. " <>
        "By default, returns the most recently associated batch. " <>
        "When `type=all`, returns a paginated list of all batches referencing this data hash.",
    parameters:
      [
        %OpenApiSpex.Parameter{
          name: :data_hash,
          in: :path,
          required: true,
          schema: Schemas.General.FullHash,
          description: "AnyTrust data hash."
        }
        | base_params()
      ] ++
        [
          %OpenApiSpex.Parameter{
            name: :type,
            in: :query,
            required: false,
            schema: %Schema{type: :string, enum: ["all"]},
            description: "When set to `all`, returns a paginated list of all batches for this data hash."
          }
        ] ++ define_paging_params(["number", "items_count"]),
    responses: [
      ok:
        {"Batch info, or paginated batch list when `type=all`.", "application/json",
         %Schema{
           oneOf: [
             Schemas.Arbitrum.BatchByAnytrust,
             paginated_response(
               items: Schemas.Arbitrum.BatchForList,
               next_page_params_example: %{"number" => 123}
             )
           ]
         }},
      not_found: NotFoundResponse.response(),
      unprocessable_entity: JsonErrorResponse.response()
    ]

  operation :batch_by_eigenda_da_info,
    summary: "Get batch by EigenDA data hash.",
    description:
      "Retrieves an Arbitrum batch associated with the given EigenDA data hash. " <>
        "By default, returns the most recently associated batch. " <>
        "When `type=all`, returns a paginated list of all batches referencing this data hash.",
    parameters:
      [
        %OpenApiSpex.Parameter{
          name: :data_hash,
          in: :path,
          required: true,
          schema: Schemas.General.FullHash,
          description: "EigenDA data hash (Keccak-256 of the blob header)."
        }
        | base_params()
      ] ++
        [
          %OpenApiSpex.Parameter{
            name: :type,
            in: :query,
            required: false,
            schema: %Schema{type: :string, enum: ["all"]},
            description: "When set to `all`, returns a paginated list of all batches for this data hash."
          }
        ] ++ define_paging_params(["number", "items_count"]),
    responses: [
      ok:
        {"Batch info, or paginated batch list when `type=all`.", "application/json",
         %Schema{
           oneOf: [
             Schemas.Arbitrum.BatchByEigenda,
             paginated_response(
               items: Schemas.Arbitrum.BatchForList,
               next_page_params_example: %{"number" => 123}
             )
           ]
         }},
      not_found: NotFoundResponse.response(),
      unprocessable_entity: JsonErrorResponse.response()
    ]

  operation :batch_by_celestia_da_info,
    summary: "Get batch by Celestia blob reference.",
    description:
      "Retrieves an Arbitrum batch whose data availability blob is identified by the given " <>
        "Celestia block height and transaction commitment hash.",
    parameters: [
      %OpenApiSpex.Parameter{
        name: :height,
        in: :path,
        required: true,
        schema: %Schema{type: :integer, minimum: 0},
        description: "Celestia block height."
      },
      %OpenApiSpex.Parameter{
        name: :transaction_commitment,
        in: :path,
        required: true,
        schema: Schemas.General.FullHash,
        description: "Celestia transaction commitment hash."
      }
      | base_params()
    ],
    responses: [
      ok: {"Batch info.", "application/json", Schemas.Arbitrum.BatchByCelestia},
      not_found: NotFoundResponse.response(),
      unprocessable_entity: JsonErrorResponse.response()
    ]

  operation :batches_count,
    summary: "Get batches count.",
    description: "Retrieves the total count of Arbitrum batches committed to the Parent chain.",
    parameters: base_params(),
    responses: [
      ok: {"Total count of batches.", "application/json", %Schema{type: :integer, minimum: 0}},
      unprocessable_entity: JsonErrorResponse.response()
    ]

  operation :batches,
    summary: "List batches.",
    description: "Retrieves a paginated list of Arbitrum batches committed to the Parent chain.",
    parameters:
      base_params() ++
        [
          %OpenApiSpex.Parameter{
            name: :batch_numbers,
            in: :query,
            required: false,
            schema: %Schema{type: :array, items: %Schema{type: :integer, minimum: 0}},
            description: "Optional list of specific batch numbers to retrieve."
          }
        ] ++ define_paging_params(["number", "items_count"]),
    responses: [
      ok:
        {"Paginated list of Arbitrum batches.", "application/json",
         paginated_response(
           items: Schemas.Arbitrum.BatchForList,
           next_page_params_example: %{"number" => 123}
         )},
      unprocessable_entity: JsonErrorResponse.response()
    ]

  operation :batch_latest_number,
    summary: "Get the latest batch number.",
    description:
      "Retrieves the number of the most recent Arbitrum batch submitted to the Parent chain. Returns 0 if no batches exist.",
    parameters: base_params(),
    responses: [
      ok: {"Latest Arbitrum batch number.", "application/json", %Schema{type: :integer, minimum: 0}},
      unprocessable_entity: JsonErrorResponse.response()
    ],
    tags: ["main-page"]

  operation :recent_messages_to_l2,
    summary: "List recent Parent chain to Rollup messages on the main page.",
    description: "Retrieves the most recent relayed messages from Parent chain to Rollup, displayed on the main page.",
    parameters: base_params(),
    responses: [
      ok:
        {"List of recent Parent chain to Rollup messages.", "application/json",
         %Schema{
           type: :object,
           properties: %{
             items: %Schema{
               type: :array,
               items: Schemas.Arbitrum.MinimalMessage,
               nullable: false
             }
           },
           required: [:items],
           additionalProperties: false
         }},
      unprocessable_entity: JsonErrorResponse.response()
    ],
    tags: ["main-page"]

  operation :batches_committed,
    summary: "List committed batches on the main page.",
    description:
      "Retrieves a list of Arbitrum batches that have been committed to the Parent chain, displayed on the main page.",
    parameters: base_params(),
    responses: [
      ok:
        {"List of committed Arbitrum batches.", "application/json",
         %Schema{
           type: :object,
           properties: %{
             items: %Schema{
               type: :array,
               items: Schemas.Arbitrum.BatchForList,
               nullable: false
             }
           },
           required: [:items],
           additionalProperties: false
         }},
      unprocessable_entity: JsonErrorResponse.response()
    ],
    tags: ["main-page"]

  @doc """
    Function to handle GET requests to `/api/v2/arbitrum/messages/:direction` endpoint.
  """
  @spec messages(Plug.Conn.t(), map()) :: Plug.Conn.t()
  def messages(conn, %{direction: direction} = params) do
    options =
      params
      |> paging_options()

    {messages, next_page} =
      direction
      |> MessagesReader.messages(options)
      |> split_list_by_page()

    next_page_params =
      next_page_params(
        next_page,
        messages,
        params,
        false,
        fn %Message{message_id: message_id} -> %{"id" => message_id} end
      )

    conn
    |> put_status(200)
    |> render(:arbitrum_messages, %{
      messages: messages,
      next_page_params: next_page_params
    })
  end

  @doc """
    Function to handle GET requests to `/api/v2/arbitrum/messages/:direction/count` endpoint.
  """
  @spec messages_count(Plug.Conn.t(), map()) :: Plug.Conn.t()
  def messages_count(conn, %{direction: direction} = _params) do
    conn
    |> put_status(200)
    |> render(:arbitrum_messages_count, %{count: MessagesReader.messages_count(direction)})
  end

  @doc """
    Function to handle GET requests to `/api/v2/arbitrum/messages/claim/:message_id` endpoint.
  """
  @spec claim_message(Plug.Conn.t(), map()) :: Plug.Conn.t()
  def claim_message(conn, %{message_id: message_id} = _params) do
    case ClaimRollupMessage.claim(message_id) do
      {:ok, [contract_address: outbox_contract_address, calldata: calldata]} ->
        conn
        |> put_status(200)
        |> render(:arbitrum_claim_message, %{calldata: calldata, address: outbox_contract_address})

      {:error, :not_found} ->
        conn
        |> put_status(:not_found)
        |> render(:message, %{message: "cannot find requested withdrawal"})

      {:error, :sent} ->
        conn
        |> put_status(:bad_request)
        |> render(:message, %{message: "withdrawal is unconfirmed yet"})

      {:error, :initiated} ->
        conn
        |> put_status(:bad_request)
        |> render(:message, %{message: "withdrawal is just initiated, please wait a bit"})

      {:error, :relayed} ->
        conn
        |> put_status(:bad_request)
        |> render(:message, %{message: "withdrawal was executed already"})

      {:error, :internal_error} ->
        conn
        |> put_status(:not_found)
        |> render(:message, %{message: "internal error occurred"})
    end
  end

  @doc """
    Function to handle GET requests to `/api/v2/arbitrum/messages/withdrawals/:transaction_hash` endpoint.
  """
  @spec withdrawals(Plug.Conn.t(), map()) :: Plug.Conn.t()
  def withdrawals(conn, %{transaction_hash: transaction_hash} = _params) do
    hash =
      case Hash.Full.cast(transaction_hash) do
        {:ok, address} -> address
        _ -> nil
      end

    withdrawals = ClaimRollupMessage.transaction_to_withdrawals(hash)

    conn
    |> put_status(200)
    |> render(:arbitrum_withdrawals, %{withdrawals: withdrawals})
  end

  @doc """
    Function to handle GET requests to `/api/v2/arbitrum/batches/:batch_number` endpoint.
  """
  @spec batch(Plug.Conn.t(), map()) :: Plug.Conn.t()
  def batch(conn, %{batch_number: batch_number} = _params) do
    case SettlementReader.batch(batch_number, necessity_by_association: @batch_necessity_by_association) do
      {:ok, batch} ->
        conn
        |> put_status(200)
        |> render(:arbitrum_batch, %{batch: batch})

      {:error, :not_found} = res ->
        res
    end
  end

  @doc """
    Function to handle GET requests to `/api/v2/arbitrum/batches/da/anytrust/:data_hash` endpoint.
  """
  @spec batch_by_anytrust_da_info(Plug.Conn.t(), map()) :: Plug.Conn.t() | {:error, :not_found}
  # For AnyTrust, data_key is the hash of the data itself
  def batch_by_anytrust_da_info(conn, %{data_hash: data_hash} = params) do
    case Map.get(params, :type) do
      "all" -> all_batches_by_data_availability_info(conn, data_hash, params)
      _ -> one_batch_by_data_availability_info(conn, data_hash, params)
    end
  end

  @doc """
    Function to handle GET requests to `/api/v2/arbitrum/batches/da/eigenda/:data_hash` endpoint.
  """
  @spec batch_by_eigenda_da_info(Plug.Conn.t(), map()) :: Plug.Conn.t() | {:error, :not_found}
  # For EigenDA, data_key is the hash of the data itself
  def batch_by_eigenda_da_info(conn, %{data_hash: data_hash} = params) do
    case Map.get(params, :type) do
      "all" -> all_batches_by_data_availability_info(conn, data_hash, params)
      _ -> one_batch_by_data_availability_info(conn, data_hash, params)
    end
  end

  @doc """
    Function to handle GET requests to `/api/v2/arbitrum/batches/da/celestia/:height/:transaction_commitment` endpoint.
  """
  @spec batch_by_celestia_da_info(Plug.Conn.t(), map()) :: Plug.Conn.t() | {:error, :not_found}
  def batch_by_celestia_da_info(
        conn,
        %{transaction_commitment: transaction_commitment, height: height} = _params
      ) do
    with {:ok, :hash, transaction_commitment_hash} <- parse_block_hash_or_number_param(transaction_commitment) do
      key = calculate_celestia_data_key(height, transaction_commitment_hash)

      case SettlementReader.get_da_record_by_data_key(key) do
        {:ok, {batch_number, _}} ->
          batch(conn, %{batch_number: batch_number})

        {:error, :not_found} = res ->
          res
      end
    end
  end

  # Gets the most recent batch associated with the given DA blob hash.
  #
  # ## Parameters
  # - `conn`: The connection struct
  # - `data_hash`: The AnyTrust or EigenDA data hash
  # - `params`: The original request parameters
  #
  # ## Returns
  # - The connection struct with rendered response
  @spec one_batch_by_data_availability_info(Plug.Conn.t(), binary(), map()) ::
          Plug.Conn.t() | {:error, :not_found}
  defp one_batch_by_data_availability_info(conn, data_hash, _params) do
    case SettlementReader.get_da_record_by_data_key(data_hash) do
      {:ok, {batch_number, _}} ->
        batch(conn, %{batch_number: batch_number})

      {:error, :not_found} = res ->
        res
    end
  end

  # Gets all batches associated with the given DA blob hash.
  #
  # ## Parameters
  # - `conn`: The connection struct
  # - `data_hash`: The AnyTrust or EigenDA data hash
  # - `params`: The original request parameters (for pagination)
  #
  # ## Returns
  # - The connection struct with rendered response
  @spec all_batches_by_data_availability_info(Plug.Conn.t(), binary(), map()) ::
          Plug.Conn.t() | {:error, :not_found}
  defp all_batches_by_data_availability_info(conn, data_hash, params) do
    case SettlementReader.get_all_da_records_by_data_key(data_hash) do
      {:ok, {batch_numbers, _}} ->
        params = Map.put(params, :batch_numbers, batch_numbers)
        batches(conn, params)

      {:error, :not_found} = res ->
        res
    end
  end

  @doc """
    Function to handle GET requests to `/api/v2/arbitrum/batches/count` endpoint.
  """
  @spec batches_count(Plug.Conn.t(), map()) :: Plug.Conn.t()
  def batches_count(conn, _params) do
    conn
    |> put_status(200)
    |> render(:arbitrum_batches_count, %{count: SettlementReader.batches_count()})
  end

  @doc """
    Function to handle GET requests to `/api/v2/arbitrum/batches` endpoint.

    The function can be called in two ways:
    1. Without batch_numbers parameter - returns batches according to pagination parameters
    2. With batch_numbers parameter - returns only batches with specified numbers, still applying pagination

    ## Parameters
    - `conn`: The connection struct
    - `params`: A map that may contain:
      * `batch_numbers` - Optional list of specific batch numbers to retrieve
      * Standard pagination parameters
  """
  @spec batches(Plug.Conn.t(), map()) :: Plug.Conn.t()
  def batches(conn, params) do
    {batches, next_page} =
      params
      |> paging_options()
      |> maybe_add_batch_numbers(params)
      |> Keyword.put(:necessity_by_association, @batch_necessity_by_association)
      |> SettlementReader.batches()
      |> split_list_by_page()

    next_page_params =
      next_page_params(
        next_page,
        batches,
        params,
        false,
        fn %L1Batch{number: number} -> %{"number" => number} end
      )

    conn
    |> put_status(200)
    |> render(:arbitrum_batches, %{
      batches: batches,
      next_page_params: next_page_params
    })
  end

  # Adds batch_numbers to options if they are present in params.
  #
  # ## Parameters
  # - `options`: The keyword list of options to potentially extend
  # - `params`: The params map that may contain batch_numbers
  #
  # ## Returns
  # - The options keyword list, potentially extended with batch_numbers
  @spec maybe_add_batch_numbers(Keyword.t(), map()) :: Keyword.t()
  defp maybe_add_batch_numbers(options, %{batch_numbers: batch_numbers}) when is_list(batch_numbers) do
    Keyword.put(options, :batch_numbers, batch_numbers)
  end

  defp maybe_add_batch_numbers(options, _params), do: options

  @doc """
    Function to handle GET requests to `/api/v2/main-page/arbitrum/batches/committed` endpoint.
  """
  @spec batches_committed(Plug.Conn.t(), map()) :: Plug.Conn.t()
  def batches_committed(conn, _params) do
    batches =
      []
      |> Keyword.put(:necessity_by_association, @batch_necessity_by_association)
      |> Keyword.put(:committed?, true)
      |> SettlementReader.batches()

    conn
    |> put_status(200)
    |> render(:arbitrum_batches, %{batches: batches})
  end

  @doc """
    Function to handle GET requests to `/api/v2/main-page/arbitrum/batches/latest-number` endpoint.
  """
  @spec batch_latest_number(Plug.Conn.t(), map()) :: Plug.Conn.t()
  def batch_latest_number(conn, _params) do
    conn
    |> put_status(200)
    |> render(:arbitrum_batch_latest_number, %{number: batch_latest_number()})
  end

  defp batch_latest_number do
    case SettlementReader.batch(:latest) do
      {:ok, batch} -> batch.number
      {:error, :not_found} -> 0
    end
  end

  @doc """
    Function to handle GET requests to `/api/v2/main-page/arbitrum/messages/to-rollup` endpoint.
  """
  @spec recent_messages_to_l2(Plug.Conn.t(), map()) :: Plug.Conn.t()
  def recent_messages_to_l2(conn, _params) do
    messages = MessagesReader.relayed_l1_to_l2_messages(paging_options: %PagingOptions{page_size: 6})

    conn
    |> put_status(200)
    |> render(:arbitrum_messages, %{messages: messages})
  end
end

# VITAY v2.3 Security Hardening

VITAY is an educational/testnet blockchain prototype. This release focuses on deterministic validation and safer chain replacement.

## Added
- Reorganization depth limit (`MAX_REORG_DEPTH=100`).
- Local checkpoint endpoint/data helper for audit and recovery.
- Candidate chain is fully validated before replacement.
- Invalid candidate chains leave the current chain untouched.
- Removed Python cache artifacts from the distribution.

## Not a security guarantee
No software-only change can guarantee a blockchain is secure. Before any real-value deployment, use independent review, adversarial testing, key-management review, network hardening, monitoring, and a formal release process.

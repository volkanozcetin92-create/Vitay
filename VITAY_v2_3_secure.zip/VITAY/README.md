# VITAY v2.3 Secure

VITAY (VITAY), maksimum 10.550.000 arzlı eğitim/testnet blockchain prototipidir.

Bu sürüm; Ed25519 imzaları, nonce/replay koruması, kontrollü emisyon, PoW, mempool sınırları, P2P node, SQLite kalıcılığı ve zincir değiştirme güvenlik kontrollerini içerir.

## v2.3 yenilikleri
- Reorg derinliği sınırı
- Güvenli candidate-chain doğrulaması
- Yerel checkpoint bilgisi
- Temiz dağıtım paketi (cache dosyaları yok)
- Ek güvenlik testleri

## Çalıştırma
```bash
pip install -r requirements.txt
pytest -q
```

Bu proje gerçek para/mainnet için güvenlik garantisi vermez. Bağımsız denetim olmadan gerçek değerle kullanılmamalıdır.

from .vitay import *
from .crypto import generate_keypair,sign,canonical_bytes

def main():
    c=VITAYChain(); assert c.valid() and c.minted==GENESIS_MINT
    sk1,a1=generate_keypair(); sk2,a2=generate_keypair()
    from . import vitay as m
    old=m.GENESIS_ALLOCATION.copy(); m.GENESIS_ALLOCATION={a1:1000,'FOUNDER':old['FOUNDER']-1000,**{k:v for k,v in old.items() if k!='FOUNDER'}}
    try:
        c=VITAYChain(); sig=sign(sk1,canonical_bytes({'sender':a1,'recipient':a2,'amount':100,'nonce':1})); c.add_signed_transfer(a1,a2,100,1,sig); c.mine(a1); assert c.valid() and c.balance(a2)==100
        c.chain[1].transactions[0]['amount']=101; assert not c.valid()
    finally: m.GENESIS_ALLOCATION=old
    print('VITAY v2.2 security smoke test: PASS')
if __name__=='__main__': main()

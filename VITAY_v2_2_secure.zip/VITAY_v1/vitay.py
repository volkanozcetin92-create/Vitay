#!/usr/bin/env python3
"""VITAY v2.2 consensus core - educational/testnet only."""
import hashlib, json, time
from dataclasses import dataclass, asdict
from .crypto import canonical_bytes, verify

NAME='VITAY'; PROTOCOL_VERSION=3
MAX_SUPPLY=10_550_000; BLOCK_REWARD=50; DIFFICULTY=4
MAX_TX_PER_BLOCK=500; MAX_BLOCK_BYTES=1_000_000; MAX_FUTURE_SECONDS=120
MAX_MEMPOOL=5000; MAX_TX_BYTES=16_384; MAX_ADDRESS_BYTES=64
MINING_POOL=2_110_000; REWARD_POOL=527_500
GENESIS_MINT=MAX_SUPPLY-MINING_POOL-REWARD_POOL
GENESIS_ALLOCATION={'FOUNDER':1_055_000,'COMMUNITY':2_637_500,'DEVELOPMENT':1_582_500,'LIQUIDITY':1_055_000,'RESERVE':1_055_000,'PROMOTION':527_500}

def h(x): return hashlib.sha256(x.encode() if isinstance(x,str) else x).hexdigest()
def tx_payload(sender,recipient,amount,nonce): return {'sender':sender,'recipient':recipient,'amount':amount,'nonce':nonce}
def txid(raw): return h(canonical_bytes({k:v for k,v in raw.items() if k!='txid'}))
def _is_hex64(v):
    if not isinstance(v,str) or len(v)!=64:return False
    try: bytes.fromhex(v); return True
    except ValueError:return False

@dataclass
class Block:
    index:int; timestamp:float; transactions:list; previous_hash:str; nonce:int; miner:str; hash:str=''
    def body(self): return {'index':self.index,'timestamp':self.timestamp,'transactions':self.transactions,'previous_hash':self.previous_hash,'nonce':self.nonce,'miner':self.miner}
    def calc(self): return h(canonical_bytes(self.body()))

class VITAYChain:
    def __init__(self): self.chain=[]; self.pending=[]; self._genesis()
    @property
    def balances(self): return self._replay()[0]
    @property
    def nonces(self): return self._replay()[1]
    @property
    def minted(self): return self._replay()[2]
    @property
    def mining_minted(self): return self._replay()[3]
    @property
    def reward_minted(self): return self._replay()[4]
    def _genesis(self):
        txs=[]
        for recipient,amount in sorted(GENESIS_ALLOCATION.items()):
            raw={'type':'genesis','sender':'GENESIS','recipient':recipient,'amount':amount,'nonce':0,'signature':'GENESIS'}; raw['txid']=txid(raw); txs.append(raw)
        b=Block(0,0.0,txs,'0'*64,0,'GENESIS'); b.hash=b.calc(); self.chain=[b]
    def _replay(self):
        balances={}; nonces={}; minted=0; mining_minted=0; reward_minted=0; seen=set()
        for i,b in enumerate(self.chain):
            if b.hash!=b.calc(): raise ValueError('Blok hash geçersiz')
            if b.index!=i: raise ValueError('Blok sırası geçersiz')
            if i==0:
                if b.previous_hash!='0'*64 or b.miner!='GENESIS': raise ValueError('Genesis bozuk')
            elif b.previous_hash!=self.chain[i-1].hash: raise ValueError('Önceki blok bağlantısı bozuk')
            if len(b.transactions)>MAX_TX_PER_BLOCK: raise ValueError('Blokta fazla işlem')
            if i>0:
                raw_block=json.dumps(b.body(),sort_keys=True,separators=(',',':')).encode()
                if len(raw_block)>MAX_BLOCK_BYTES: raise ValueError('Blok boyutu aşıldı')
                if not b.hash.startswith('0'*DIFFICULTY): raise ValueError('PoW geçersiz')
                if b.timestamp<=self.chain[i-1].timestamp or b.timestamp>time.time()+MAX_FUTURE_SECONDS: raise ValueError('Blok zamanı geçersiz')
            coinbases=0
            for raw in b.transactions:
                if raw.get('txid')!=txid(raw): raise ValueError('TXID geçersiz')
                if raw['txid'] in seen: raise ValueError('Tekrarlanan işlem')
                seen.add(raw['txid'])
                typ=raw.get('type','transfer')
                if typ=='genesis':
                    if i!=0 or raw.get('sender')!='GENESIS' or raw.get('signature')!='GENESIS': raise ValueError('Genesis işlemi geçersiz')
                    if raw['recipient'] not in GENESIS_ALLOCATION or raw['amount']!=GENESIS_ALLOCATION[raw['recipient']]: raise ValueError('Genesis dağıtımı geçersiz')
                    balances[raw['recipient']]=balances.get(raw['recipient'],0)+raw['amount']; minted+=raw['amount']
                elif typ=='coinbase':
                    coinbases+=1
                    if i==0 or coinbases>1 or raw.get('sender')!='SYSTEM' or raw.get('signature')!='SYSTEM' or raw.get('nonce')!=0: raise ValueError('Coinbase geçersiz')
                    if raw['recipient']!=b.miner or not isinstance(raw['amount'],int) or raw['amount']<=0 or raw['amount']>BLOCK_REWARD: raise ValueError('Coinbase ödülü geçersiz')
                    balances[b.miner]=balances.get(b.miner,0)+raw['amount']; minted+=raw['amount']
                    base=min(raw['amount'],MINING_POOL-mining_minted); mining_minted+=base; reward_minted+=raw['amount']-base
                elif typ=='transfer':
                    if len(canonical_bytes(raw))>MAX_TX_BYTES: raise ValueError('İşlem çok büyük')
                    sender,recipient,amount,nonce=raw['sender'],raw['recipient'],raw['amount'],raw['nonce']
                    if not _is_hex64(sender) or not _is_hex64(recipient) or sender==recipient: raise ValueError('Adres geçersiz')
                    if not isinstance(amount,int) or amount<=0: raise ValueError('Miktar geçersiz')
                    if not isinstance(nonce,int) or nonce!=nonces.get(sender,0)+1: raise ValueError('Nonce sırası geçersiz')
                    if not verify(sender,raw['signature'],canonical_bytes(tx_payload(sender,recipient,amount,nonce))): raise ValueError('İmza geçersiz')
                    if balances.get(sender,0)<amount: raise ValueError('Bakiye yetersiz')
                    balances[sender]-=amount; balances[recipient]=balances.get(recipient,0)+amount; nonces[sender]=nonce
                else: raise ValueError('Bilinmeyen işlem türü')
        if minted>MAX_SUPPLY or mining_minted>MINING_POOL or reward_minted>REWARD_POOL: raise ValueError('Emisyon sınırı aşıldı')
        if minted!=sum(balances.values()): raise ValueError('Arz/bakiye tutarsızlığı')
        return balances,nonces,minted,mining_minted,reward_minted
    def balance(self,a): return self.balances.get(a,0)
    def next_nonce(self,a):
        n=self.nonces.get(a,0)
        for t in self.pending:
            if t.get('sender')==a: n=max(n,t['nonce'])
        return n+1
    def add_signed_transfer(self,sender,recipient,amount,nonce,signature):
        if len(self.pending)>=MAX_MEMPOOL: raise ValueError('Mempool dolu')
        if not _is_hex64(sender) or not _is_hex64(recipient) or sender==recipient: raise ValueError('Geçersiz adres')
        if not isinstance(amount,int) or amount<=0: raise ValueError('Geçersiz miktar')
        payload=tx_payload(sender,recipient,amount,nonce)
        raw={'type':'transfer',**payload,'signature':signature}; raw['txid']=txid(raw)
        if len(canonical_bytes(raw))>MAX_TX_BYTES: raise ValueError('İşlem çok büyük')
        if nonce!=self.next_nonce(sender): raise ValueError('Geçersiz nonce')
        if not verify(sender,signature,canonical_bytes(payload)): raise ValueError('Ed25519 imzası geçersiz')
        reserved=sum(t['amount'] for t in self.pending if t['sender']==sender)
        if self.balance(sender)-reserved<amount: raise ValueError('Yetersiz bakiye')
        if any(t['txid']==raw['txid'] for t in self.pending): raise ValueError('İşlem zaten mempoolda')
        self.pending.append(raw); return raw['txid']
    def _reward(self): return min(BLOCK_REWARD,(MINING_POOL-self.mining_minted)+(REWARD_POOL-self.reward_minted))
    def mine(self,miner):
        if not _is_hex64(miner): raise ValueError('Madenci adresi geçersiz')
        reward=self._reward()
        if reward<=0: raise ValueError('Madencilik ödül havuzu tükendi')
        coinbase={'type':'coinbase','sender':'SYSTEM','recipient':miner,'amount':reward,'nonce':0,'signature':'SYSTEM'}; coinbase['txid']=txid(coinbase)
        b=Block(len(self.chain),max(time.time(),self.chain[-1].timestamp+0.000001),list(self.pending)+[coinbase],self.chain[-1].hash,0,miner)
        while True:
            b.hash=b.calc()
            if b.hash.startswith('0'*DIFFICULTY): break
            b.nonce+=1
        self.chain.append(b)
        try:self._replay()
        except Exception:self.chain.pop(); raise
        self.pending=[]; return b
    def work_score(self): return len(self.chain)-1
    def valid(self):
        try:self._replay(); return True
        except Exception:return False
    def export(self): return {'protocol_version':PROTOCOL_VERSION,'chain':[asdict(b) for b in self.chain]}
    def import_chain(self,data):
        if int(data.get('protocol_version',0))!=PROTOCOL_VERSION: raise ValueError('Protokol sürümü uyuşmuyor')
        if not isinstance(data.get('chain'),list) or not data['chain']: raise ValueError('Zincir verisi geçersiz')
        if len(data['chain'])>1_000_000: raise ValueError('Zincir çok büyük')
        candidate=[Block(**b) for b in data['chain']]; old=self.chain; self.chain=candidate
        try:self._replay()
        except Exception:self.chain=old; raise
        self.pending=[]

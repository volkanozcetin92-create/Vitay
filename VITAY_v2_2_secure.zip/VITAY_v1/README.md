# VITAY v2.2 Secure Testnet

VITAY is an educational blockchain/testnet prototype with a fixed maximum supply of 10,550,000 VITAY.

This project is **not a mainnet, investment product, or security guarantee**. It must receive independent review before any real-value use.

## v2.2 hardening
- Ed25519 signed transfers
- nonce/replay protection
- deterministic TXIDs
- mempool limits and duplicate protection
- block/transaction size limits
- one bounded coinbase reward per block
- fixed emission pools and maximum supply enforcement
- PoW, hash-link and chain validation
- atomic chain import
- SQLite/P2P components from previous versions

Run the smoke test:

```bash
python -m VITAY_v1.test_vitay
```

Install dependencies from `requirements.txt`.

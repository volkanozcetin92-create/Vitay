# VITAY v2.4 Security Hardening

VITAY is an educational/testnet blockchain prototype.

## v2.4 changes
- Wallet file format bumped to version 2.
- Wallet private keys remain encrypted with AES-256-GCM and PBKDF2-HMAC-SHA256.
- Wallet files are created with restrictive `0600` permissions where supported.
- Wallet saves use a temporary file plus atomic replacement and `fsync`.
- Wallet loader validates version, key lengths, base64 fields, and address/public-key consistency.
- Wallet files never store the password or plaintext private key.
- Node JSON requests have a nesting-depth limit to reduce parser/resource abuse.
- Existing chain validation, reorg protection, PoW and emission limits remain enabled.

## Not a security guarantee
This remains testnet software. Before any real-value deployment, use independent security review, fuzzing, adversarial multi-node testing, key-management review, TLS/firewall/rate limiting, monitoring, and a formal consensus specification.

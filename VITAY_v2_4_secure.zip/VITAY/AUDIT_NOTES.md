# VITAY v2.2 Audit Notes

Educational/testnet software; not a production cryptocurrency.

Implemented hardening:
- Ed25519 transaction signatures and deterministic transaction IDs.
- Strict nonce ordering and mempool duplicate/replay checks.
- Mempool, transaction, block and imported-chain size limits.
- Exactly one coinbase transaction per non-genesis block.
- Coinbase reward capped at BLOCK_REWARD and bounded by emission pools.
- Deterministic block-link, hash and proof-of-work validation.
- Genesis allocation is validated against the fixed allocation table.
- Chain import is atomic: invalid candidate chains are rejected without replacing the current chain.
- Protocol version bumped to 3 for incompatible validation changes.

Before any real-value deployment, commission independent security review, fuzzing, multi-node adversarial tests, key-management review, and a formal consensus specification.

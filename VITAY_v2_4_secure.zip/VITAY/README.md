# VITAY v2.4 Secure

VITAY (VITAY), maksimum 10.550.000 arzlı eğitim/testnet blockchain prototipidir.

Bu sürüm; Ed25519 imzaları, nonce/replay koruması, kontrollü emisyon, PoW, mempool sınırları, P2P node, SQLite kalıcılığı, zincir değiştirme güvenlik kontrolleri ve güçlendirilmiş şifreli cüzdan içerir.

## v2.4 yenilikleri
- Şifreli cüzdan formatı v2
- AES-256-GCM + PBKDF2-HMAC-SHA256 ile özel anahtar koruması
- Cüzdan dosyasında parola/özel anahtar tutulmaması
- Kısıtlayıcı dosya izinleri (`0600`, desteklenen sistemlerde)
- Atomik cüzdan kaydı + `fsync`
- Cüzdan alanları ve anahtar uzunluğu doğrulaması
- Node JSON derinlik sınırı
- Önceki reorg, checkpoint ve zincir doğrulama kontrollerinin korunması

## Çalıştırma
```bash
pip install -r requirements.txt
pytest -q
```

Bu proje gerçek para/mainnet için güvenlik garantisi vermez. Bağımsız denetim olmadan gerçek değerle kullanılmamalıdır.

from .vitay import *
from .crypto import generate_keypair,sign,canonical_bytes
from .wallet import create_wallet,save_wallet,load_wallet
import json, os, stat, tempfile

def main():
    c=VITAYChain(); assert c.valid() and c.minted==GENESIS_MINT
    sk1,a1=generate_keypair(); sk2,a2=generate_keypair()
    from . import vitay as m
    old=m.GENESIS_ALLOCATION.copy(); m.GENESIS_ALLOCATION={a1:1000,'FOUNDER':old['FOUNDER']-1000,**{k:v for k,v in old.items() if k!='FOUNDER'}}
    try:
        c=VITAYChain(); sig=sign(sk1,canonical_bytes({'sender':a1,'recipient':a2,'amount':100,'nonce':1})); c.add_signed_transfer(a1,a2,100,1,sig); c.mine(a1); assert c.valid() and c.balance(a2)==100
        c.chain[1].transactions[0]['amount']=101; assert not c.valid()
    finally: m.GENESIS_ALLOCATION=old
    print('VITAY security smoke test: PASS')


def test_tampered_import_does_not_replace_chain():
    c=VITAYChain(); original=c.export(); bad=c.export(); bad['chain'][0]['hash']='0'*64
    try: c.import_chain(bad)
    except ValueError: pass
    assert c.export()==original

def test_checkpoint():
    c=VITAYChain(); cp=c.checkpoint(); assert cp['height']==0 and cp['hash']==c.chain[0].hash

def test_wallet_roundtrip_and_wrong_password():
    with tempfile.TemporaryDirectory() as d:
        path=os.path.join(d,'wallet.json'); w=create_wallet('correct horse battery staple'); save_wallet(w,path)
        mode=stat.S_IMODE(os.stat(path).st_mode); assert mode & 0o077 == 0
        loaded=load_wallet(path,'correct horse battery staple')
        assert loaded['address']==w['address'] and loaded['private_key']==w['private_key']
        try: load_wallet(path,'wrong password')
        except Exception: pass
        else: assert False
        raw=open(path,encoding='utf-8').read(); assert w['private_key'] not in raw and w['password'] not in raw

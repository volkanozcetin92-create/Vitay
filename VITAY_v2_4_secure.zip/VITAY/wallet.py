"""Local VITAY wallet with password-encrypted Ed25519 private key."""
import base64, json, os, stat
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from .crypto import generate_keypair

ITERATIONS=600_000
WALLET_VERSION=2
SALT_BYTES=16
NONCE_BYTES=12


def _key(password,salt):
    if not isinstance(password,str) or len(password)<8:
        raise ValueError('Cüzdan parolası en az 8 karakter olmalı.')
    if not isinstance(salt,(bytes,bytearray)) or len(salt)!=SALT_BYTES:
        raise ValueError('Geçersiz salt.')
    return PBKDF2HMAC(algorithm=hashes.SHA256(),length=32,salt=bytes(salt),iterations=ITERATIONS).derive(password.encode('utf-8'))


def create_wallet(password):
    if not isinstance(password,str) or len(password)<8: raise ValueError('Cüzdan parolası en az 8 karakter olmalı.')
    private_hex,public_hex=generate_keypair()
    # Password is intentionally not persisted in the wallet file. Keep it only for caller convenience.
    return {'address':public_hex,'private_key':private_hex,'public_key':public_hex,'password':password}


def save_wallet(wallet,path):
    password=wallet.get('password')
    if not password: raise ValueError('Kaydetmek için parola gerekli.')
    if wallet.get('address')!=wallet.get('public_key'): raise ValueError('Adres/public key uyuşmuyor.')
    try: private=bytes.fromhex(wallet['private_key']); public=bytes.fromhex(wallet['public_key'])
    except Exception: raise ValueError('Geçersiz anahtar biçimi.')
    if len(private)!=32 or len(public)!=32: raise ValueError('Geçersiz Ed25519 anahtar uzunluğu.')
    salt,nonce=os.urandom(SALT_BYTES),os.urandom(NONCE_BYTES)
    ct=AESGCM(_key(password,salt)).encrypt(nonce,private,public)
    data={'version':WALLET_VERSION,'address':wallet['address'],'public_key':wallet['public_key'],'salt':base64.b64encode(salt).decode(),'nonce':base64.b64encode(nonce).decode(),'ciphertext':base64.b64encode(ct).decode()}
    tmp=f'{path}.tmp-{os.getpid()}'
    flags=os.O_WRONLY|os.O_CREAT|os.O_TRUNC
    fd=os.open(tmp,flags,0o600)
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f:
            json.dump(data,f,indent=2); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
        try: os.chmod(path,0o600)
        except OSError: pass
    finally:
        if os.path.exists(tmp): os.unlink(tmp)


def load_wallet(path,password):
    with open(path,encoding='utf-8') as f: data=json.load(f)
    if data.get('version')!=WALLET_VERSION: raise ValueError('Desteklenmeyen cüzdan sürümü.')
    if data.get('address')!=data.get('public_key'): raise ValueError('Adres/public key uyuşmuyor.')
    try:
        public=bytes.fromhex(data['public_key'])
        salt=base64.b64decode(data['salt'],validate=True)
        nonce=base64.b64decode(data['nonce'],validate=True)
        ciphertext=base64.b64decode(data['ciphertext'],validate=True)
    except Exception: raise ValueError('Cüzdan verisi bozuk.')
    if len(public)!=32 or len(salt)!=SALT_BYTES or len(nonce)!=NONCE_BYTES or len(ciphertext)<16:
        raise ValueError('Cüzdan alanları geçersiz.')
    private=AESGCM(_key(password,salt)).decrypt(nonce,ciphertext,public)
    if len(private)!=32: raise ValueError('Özel anahtar geçersiz.')
    return {'address':data['address'],'public_key':data['public_key'],'private_key':private.hex(),'password':password}

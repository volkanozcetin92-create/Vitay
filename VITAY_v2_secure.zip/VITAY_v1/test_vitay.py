from .vitay import VITAYChain, GENESIS_MINT, MAX_SUPPLY, MINING_POOL, REWARD_POOL
from .crypto import generate_keypair, sign, canonical_bytes

def main():
    c=VITAYChain(); assert c.valid(); assert c.minted==GENESIS_MINT
    sk1,a1=generate_keypair(); sk2,a2=generate_keypair()
    c.chain[0].transactions[0]['recipient'] = 'FOUNDER'  # ensure mutation detection test
    assert not c.valid()
    c=VITAYChain()
    # Fund test sender using a fresh genesis-like address is intentionally not possible;
    # use a deterministic temporary chain with a valid genesis allocation replaced for the test.
    from . import vitay as m
    old=m.GENESIS_ALLOCATION.copy(); m.GENESIS_ALLOCATION={a1:1000,'FOUNDER':old['FOUNDER']-1000,**{k:v for k,v in old.items() if k!='FOUNDER'}}
    c=VITAYChain(); assert c.valid()
    sig=sign(sk1,canonical_bytes({'sender':a1,'recipient':a2,'amount':100,'nonce':1}))
    c.add_signed_transfer(a1,a2,100,1,sig); b=c.mine(a1); assert c.valid()
    assert c.balance(a2)==100
    assert c.minted<=MAX_SUPPLY
    assert c.mining_minted<=MINING_POOL and c.reward_minted<=REWARD_POOL
    m.GENESIS_ALLOCATION=old
    print('VITAY v2 güvenlik smoke test: PASS')

if __name__=='__main__': main()

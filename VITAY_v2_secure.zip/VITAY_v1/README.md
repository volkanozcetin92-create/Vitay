# VITAY v2 — Güvenlik odaklı eğitim/testnet blockchain

**VITAY maksimum arzı: 10.550.000.** Bu yazılım şu anda üretim finans sistemi değil, eğitim/testnet projesidir.

## Dağıtım
- Founder: 1.055.000 (10%)
- Mining: 2.110.000 (20%) — emisyon havuzu
- Mining rewards: 527.500 (5%) — emisyon havuzu
- Community: 2.637.500 (25%)
- Development: 1.582.500 (15%)
- Liquidity: 1.055.000 (10%)
- Reserve: 1.055.000 (10%)
- Promotion/Ecosystem: 527.500 (5%)

Madencilik havuzları başlangıçta basılmaz; blok ödülleriyle kontrollü olarak dolaşıma girer. Böylece toplam arz 10.550.000 sınırını aşamaz.

## Güvenlik
Ed25519 imzaları, nonce/replay koruması, deterministik consensus doğrulaması, genesis sabitlemesi, coinbase doğrulaması, PoW, blok sınırları ve kalıcı SQLite depolama kullanılır. Ayrıntılar `SECURITY.md` dosyasındadır.

## Çalıştırma
```bash
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
python -m vitay.node --port 5000
```

İnternete açık gerçek bir ağ olarak kullanmadan önce bağımsız denetim ve güvenlik testleri gerekir.
